public class Main
{
	public static void main(String[] args) {
		
		
                                    // STRING and STRINGBUFFER class
                                    
    // 1.
    
    
//     String s=new String("Hello");
//     String s1="Hello";
// //     s.concat("Hai");
// //     s1.concat("Hai");
// //     System.out.println(s);
// // 	System.out.println(s1);
// 	//s.append("Hai");    // error: cannot find symbol
// 	//s1.append("Hai");   // error: cannot find symbol
// // 	StringBuffer s2=new StringBuffer("Hello");
// // 	//s2.concat("Hai")  // error: cannot find symbol
// // 	s2.append("Hai");
// // 	System.out.println(s2);
// // 	s=s.concat("Hai");
// // 	System.out.println(s);
// 	String s3=new String("Hello");
// 	String s4="Hello";
// 	System.out.println(s==s3);
// 	System.out.println(s1==s4);
// 	System.out.println(s==s1);
// 	System.out.println(s.equals(s3));
// 	System.out.println(s1.equals(s4));
// 	System.out.println(s1.equals(s3));


    
   
   
    // 2. // String class Constructor 
    
   
    // String s=new String();
    // String s=new String("Hello");
    // StringBuffer sb=new StringBuffer("Hai");
    // String s=new String(sb);
    // StringBuilder sb=new StringBuilder("Kai");
    // String s=new String(sb);
    // char[] a={'H','E','L','L','O'};
    // String s=new String(a);
    // byte[] a={65,66,67,68,69};
    // String s=new String(a);
    // System.out.println(s);
    
    
    
    
    
    // 3. // String class Methods
    
    
    // String s=new String("Hello World");
    // String s1=new String("hello World");
    // String s2=new String("Hello");
    // String s3=new String("Hello");
    // String s4=new String("He");
    // String s5=new String("he");
    // String s6=new String("Helloh");
    // System.out.println(s.concat("Hai"));
    // System.out.println(s);
    // System.out.println(s.isEmpty());
    // System.out.println(s.equals(s1));
    // System.out.println(s.equalsIgnoreCase(s1));
    // System.out.println(s.length());
    // System.out.println(s.replace('l','t'));
    // System.out.println(s.replace(s.charAt(2),'t'));
    // System.out.println(s.replace("Hello","Hai"));
    // System.out.println(s.replaceFirst("l","t"));
    // System.out.println(s.replaceLast("l","t"));
    // System.out.println(s.substring(6));
    // System.out.println(s.substring(6,8));
    // System.out.println(s.indexOf('o'));
    // System.out.println(s.firstindexOf('o'));
    // System.out.println(s.lastindexOf('o'));
    // System.out.println(s.toLowerCase());
    // System.out.println(s.toUpperCase());
    // System.out.println(s2.compareTo(s3));
    // System.out.println(s2.compareTo(s4));
    // System.out.println(s2.compareTo(s5));
    // System.out.println(s2.compareTo(s6));
    
    
    
    
    
    // 4. // StringBuffer class Constructor 
    
   
    // StringBuffer s=new StringBuffer();
    // StringBuffer s=new StringBuffer("Hello");
    // String sb=new String("Hai");
    // StringBuffer s=new StringBuffer(sb);
    // StringBuilder sb=new StringBuilder("Kai");
    // StringBuffer s=new StringBuffer(sb);
    // System.out.println(s);
    
    
    
    
    // 5. // StringBuffer class Capacity
    
    
    // StringBuffer s=new StringBuffer("Hello");
    // StringBuffer s1=new StringBuffer("");
    // System.out.println(s1.capacity());
    // System.out.println(s.capacity());
    // s.append("abcde fghij klmn");
    // System.out.println(s.capacity());
    // s.append("p");
    // System.out.println(s.capacity());
    
    
    
    
    // 6. // StringBuffer class Mehods
    
    
    StringBuffer s=new StringBuffer("Hello");
    StringBuffer s1=new StringBuffer("");
    // System.out.println(s.length());
    // System.out.println(s.charAt(4));
    // s.setCharAt(1,'a');
    // System.out.println(s);
    // System.out.println(s.append("Hai"));
    // System.out.println(s.insert(2,"Hai"));
    // System.out.println(s.insert(2,20));
    // System.out.println(s.delete(2,s.length()));
    // System.out.println(s.deleteCharAt(2));
    // System.out.println(s.reverse());
    // s.setLength(3);
    // System.out.println(s);
    // System.out.println(s.capacity());
    // s.ensurecapacity(40);
    // System.out.println(s.capacity());
    
    
    
    
    
    
    
    
    
	
	}
}
