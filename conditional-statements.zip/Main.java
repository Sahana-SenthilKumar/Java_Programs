/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    
/*.     1. //Equal or not

	    Scanner sc=new Scanner(System.in); 
		System.out.println("Enter two numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		if(a==b)
		    System.out.println("Number1 and Number2 are equal");
		else
		    System.out.println("Number1 and Number2 are not equal");
		    

 
        2. //Odd or Even
 
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a number");
		int a=sc.nextInt();
		if(a%2==0)
		    System.out.println(a+" is an even integer");
		else
		    System.out.println(a+" is an odd integer");
		    
		3. //Postive or Negative
		
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a number");
		int a=sc.nextInt();
		if(a>=0)
		    System.out.println(a+" is a positive number");
		else
		    System.out.println(a+" is a negative number");
		    
		4. //Leap year
		
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a year");
		int a=sc.nextInt();
		if(a%400==0)
		    System.out.println(a+" is a leap year.");
		else if(a%100==100)
		    System.out.println(a+" is not a leap year.");
		else if(a%4==0)
		    System.out.println(a+" is a leap year.");
		else
		    System.out.println(a+" is not a leap year.");
		    
		5. //Vote Eligible
		
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter candidate's age");
		int a=sc.nextInt();
		if(a>=18)
		    System.out.println("Congratulation! You are eligible for casting your vote.");
		else
		    System.out.println("You are not eligible for casting your vote.");
		    
		 
		 6. //'M' and 'N'
		 
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a integer 'm'");
		int m=sc.nextInt();
		int n;
		if(m>0)
		    n=1;
		else if(m==0)
		    n=0;
		else
		    n=-1;
		 System.out.println("The value of n = "+n);
		 
		 7. //Height
		 
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter the height the person in centimeter :");
		int a=sc.nextInt();
		if(a<150)
		    System.out.println("The person is Dwarf.");
		else if(a<175)
		    System.out.println("The person is  Average heighted.");
		else if(a<195)
		    System.out.println("The person is Tall.");
		else
		    System.out.println("Abnormal height.");
		    
		    
		 8. //Largest Number
		 
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter three numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		if(a>b && a>c)
		    System.out.println("The 1st Number is the greatest among three.");
		else if(b>a && b>c)
		    System.out.println("The 2nd Number is the greatest among three.");
		else 
		    System.out.println("The 3rd Number is the greatest among three.");
		    
		 
		9. //Coordinates
		 
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter the two 'x' and 'y' coordinates");
		int x=sc.nextInt();
		int y=sc.nextInt();
		if(x>0 && y>0)
		    System.out.format("The coordinate point (%d,%d) lies in the First quadrant.",x,y);
		else if(x<0 && y>0)
		    System.out.format("The coordinate point (%d,%d) lies in the Second quadrant.",x,y);
		    else if(x<0 && y<0)
		    System.out.format("The coordinate point (%d,%d) lies in the Third quadrant.",x,y);
		else if(x>0 && y<0)
		    System.out.format("The coordinate point (%d,%d) lies in the Fourth quadrant.",x,y);
		else 
		    System.out.format("The coordinate point (%d,%d) lies in the Origin.",x,y);
		    
		
		10. //Prossional Course Admission
		
		Scanner sc=new Scanner(System.in); 
		System.out.println("Input the marks obtained in Maths :);
		int x=sc.nextInt();
		System.out.println("Input the marks obtained in Physics :);
		int y=sc.nextInt();
		System.out.println("Input the marks obtained in Chemistry :);
		int z=sc.nextInt();
		int total=(x+y+z), cutoff=(x+y);
		if( x>=65 && y>=55 && z>=50 && total>=190 && cutoff>=140)
		    System.out.format("The candidate is eligible for admission.");
		else 
		    System.out.format("The candidate is not eligible for admission.");
		
		
		11. //Quadratic Equation
		

        Scanner sc=new Scanner(System.in); 
		System.out.println("Input the value of a, b & c : ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		double determinant=(b*b)-(4*a*c), root1, root2;
		if(determinant>0){
		    root1=((-b) + Math.sqrt(determinant)) / (2*a);
		    root2=((-b) - Math.sqrt(determinant)) / (2*a);
		    System.out.format("The roots (%f,%f) are real and different",root1,root2);
		}
		else if(determinant==0){
		    root1=(-b) / (2*a);
		    root2=(-b) / (2*a);
		    System.out.format("The roots (%f,%f) are real and equal",root1,root2);
		}
		else
		    System.out.format("The roots are imaginary");
 
 
        12. //Marks Statement
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Input the Roll Number of the student : ");
		int a=sc.nextInt();
		sc.nextLine();
		System.out.println("Input the Name of the Student : ");
		String b=sc.nextLine();
		System.out.println("Input the marks of Physics, Chemistry and Computer Application in order : ");
		int c=sc.nextInt();
		int d=sc.nextInt();
		int e=sc.nextInt();
		int total=(e+d+c);
		String division;
		double percentage=(total/3);
		if(percentage>=80)
		    division ="First";
		else if(percentage>=60)
		    division ="Second";
		else if(percentage>=40)
		    division ="Third";
		else
		    division ="Fail";
		System.out.println("Roll No : "+a);
		System.out.println("Name of Student : "+b);
		System.out.println("Marks in Physics : "+c);
		System.out.println("Marks in Chemistry : "+d);
		System.out.println("Marks in Computer Application : "+e);
		System.out.println("Total Marks = "+total);
		System.out.println("Percentage = "+percentage);
		System.out.println("Division = "+division);
		


        13. //Temperature
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter the temperature in centigrade :");
		int a=sc.nextInt();
		if(a>=40)
		    System.out.println("Its Very Hot");
		else if(a>=30)
		    System.out.println("Its Hot");
		else if(a>=20)
		    System.out.println("Normal in Temp");
		else if(a>=10)
		    System.out.println("Cold weather");
		else if(a>=0)
		    System.out.println("Very Cold weather");
		else
		    System.out.println("Freezing weather");



        14. //Triangle
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter the 3 sides(angles) of the triangle");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		if(a==b && b==c)
		    System.out.println("This is an equilateral triangle.");
		else if(a==c || b==c || b==a)
		    System.out.println("This is an isosceles triangle");
		else 
		    System.out.println("This is a scalene triangle.");


        15. //Valid triangle
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter the 3 sides(angles) of the triangle");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		int triangle=a+b+c;
		if(triangle==180)
		    System.out.println("The triangle is valid.");
		else 
		    System.out.println("The triangle is invalid.");
		    


        16. //Check Character
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a character");
		char a=sc.next().charAt(0);
		if(a<='Z' && a>='A' || a<='z' && a>='a' )
		    System.out.println("This is an alphabet.");
		else if(a<='9' && a>='0')
		    System.out.println("This is a digit.");
		else 
		    System.out.println("This is a special character.");

		


        17. //Vowel or consonant
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter an aplhabet character");
		char a=sc.next().charAt(0);
		if(a=='a' || a=='A' || a=='e'|| a=='E' || a=='i' || a=='I' || a=='o'|| a=='O' || a=='u'|| a=='U')
		    System.out.println("The alphabet is a vowel.");
		else if (a<='Z' && a>='A' || a<='z' && a>='a') 
		    System.out.println("The alphabet is a consonant.");
		else
		    System.out.println("This is not an alphabet character.");



        18. //Profit and Loss
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter the Cost Price : ");
		int a=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the Selling Price : ");
		int b=sc.nextInt();
		if(a<b){
		    int profit=b-a;
		    System.out.println("You can booked your profit amount :"+profit);
		   
		}
		else if(a==b)
		    System.out.println("You are in a no profit, no loss condition.");
		else{
		    int loss=a-b;
		    System.out.println("You incurred a loss of amount :"+loss);
		}
		


        19. //Electric Bill
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter your Customer ID : ");
		int a=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Name your name : ");
		String b=sc.nextLine();
		System.out.println("Input the unit of electricity consumed : ");
		int c=sc.nextInt();
		double charge, unit, subcharge=0;
		if(c<=199){
		    unit=1.20;
		    charge=c*unit;
		}
		    
		else if(c<400){
		    unit=1.50;
		    charge=c*unit;
		}
		    
		else if(c<600){
		    unit=1.80;
		    charge=c*unit;
		}
		    
		else{
		    unit=2.00;
		    charge=c*unit;
		}
		
		double net=charge;
		    
		if(charge>400){
		    subcharge=(15/100)*charge;
		    net=charge+subcharge;
		}
		else if(charge<100){
		    unit=0;
		    charge=100;
		}
		    
		
		System.out.println("Customer IDNO :"+a);
		System.out.println("Customer Name :"+b);
		System.out.println("unit Consumed :"+c);
		System.out.println("Amount Charges @Rs."+unit+" per unit : "+charge);
		System.out.println("Surchage Amount : "+subcharge);
		System.out.println("Net Amount Paid By the Customer :"+net);
		


        20. //Grade

        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter your grade either 'E' or 'V' or 'G' or 'A' or 'F' : ");
		char a=sc.next().charAt(0);        
        String result;
        switch(a){
            case 'E':
                result="Excellent";
                break;
            case 'V':
                result="Very Good";
                break;
            case 'G':
                result="Good";
                break;
            case 'A':
                result="Average";
                break;
            case 'F':
                result="Fail";
                break;
            default :
                result="Invalid";
                
        }
        System.out.println("You have chosen : "+result);
		


        21. //Day Number
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a day number either '1' or '2' or '3' or '4' or '5' or '6' or '7' : ");
		int a=sc.nextInt();        
        switch(a){
            case 1:
                System.out.println("Monday");
                break;
            case 2:
                System.out.println("Tuesday");
                break;
            case 3:
                System.out.println("Wednesday");
                break;
            case 4:
                System.out.println("Thursday");
                break;
            case 5:
                System.out.println("Friday");
                break;
            case 6:
                System.out.println("Saturday");
                break;
            case 7:
                System.out.println("Sunday");
                break;
            default :
               System.out.println("Invalid Day");
                
        }
 
     
 
        22. //Digit 
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Input Digit(0-9) : ");
		int a=sc.nextInt();        
        switch(a){
            case 0:
                System.out.println("Zero");
                break;
            case 1:
                System.out.println("One");
                break;
            case 2:
                System.out.println("Two");
                break;
            case 3:
                System.out.println("Three");
                break;
            case 4:
                System.out.println("Four");
                break;
            case 5:
                System.out.println("Five");
                break;
            case 6:
                System.out.println("Six");
                break;
            case 7:
                System.out.println("Seven");
                break;
            case 8:
                System.out.println("Eight");
                break;
            case 9:
                System.out.println("Nine");
                break;
            default :
               System.out.println("Invalid Digit");
        }
        
 
 
        23. //Month
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Input Month Number : ");
		int a=sc.nextInt();        
        switch(a){
            case 1:
                System.out.println("January");
                break;
            case 2:
                System.out.println("February");
                break;
            case 3:
                System.out.println("March");
                break;
            case 4:
                System.out.println("April");
                break;
            case 5:
                System.out.println("May");
                break;
            case 6:
                System.out.println("June");
                break;
            case 7:
                System.out.println("July");
                break;
            case 8:
                System.out.println("August");
                break;
            case 9:
                System.out.println("September");
                break;
            case 10:
                System.out.println("October");
                break;
            case 11:
                System.out.println("November");
                break;
            case 12:
                System.out.println("December");
                break;
            default :
               System.out.println("Invalid Month");
        }
        


        24. //Month Days
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Input Month Number : ");
		int a=sc.nextInt();        
        switch(a){
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                System.out.println("Month has 31 days");
                break;
            case 2:
                System.out.println("February has 28 days but in leap year has 29 days");
                break;
            case 4: case 6: case 9: case 11:
                System.out.println("Month has 30 days");
                break;
            default :
               System.out.println("Invalid Month");
        }



        25. //Area
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Input 1 for area of Square\nInput 2 for area of Rectangle\nInput 3 for area of Triangle\nInput 4 for area of Circle");
		int a=sc.nextInt();
		switch(a){
            case 1: 
                System.out.println("Enter the side of the square");
                int side=sc.nextInt();
                System.out.println("Area of the square : "+(side*side));
                break;
            case 2:
                System.out.println("Enter the length and width of the rectangle");
                int l=sc.nextInt();
                int w=sc.nextInt();
                System.out.println("Area of the rectangle : "+(l*w));
                break;
            case 3: 
                System.out.println("Enter the base and height of the triangle");
                int b=sc.nextInt();
                int h=sc.nextInt();
                System.out.println("Area of the triangle : "+(0.5*b*h));
                break;
            case 4:
                System.out.println("Enter the radius of the circle");
                int r=sc.nextInt();
                System.out.println("Area of the circle : "+(3.14*r*r));
                
                break;
            default :
               System.out.println("Invalid Shape");
        
		}
        


        26. //Simple Calculation
        
        Scanner sc=new Scanner(System.in); 
		System.out.println("Input 1 for Addition\nInput 2 for Subtraction\nInput 3 for Multiplication\nInput 4 for Division");
		int a=sc.nextInt();
		System.out.println("Enter two number to perform calculation :");
		double b=sc.nextDouble();
		double c=sc.nextDouble();
		switch(a){
            case 1: 
                System.out.println("Addition of two numbers (a+b) is : "+(b+c));
                break;
            case 2:
                System.out.println("Subtraction of two numbers (a-b) is : "+(b-c));
                break;
            case 3: 
                System.out.println("Multiplication of two numbers (a*b) is : "+(b*c));
                break;
            case 4:
                System.out.println("Division of two numbers (a/b) is : "+(b/c));
                break;
            default :
               System.out.println("Invalid Option");
        
		}
        
*/  

  
        
        
	}
}
