import java.util.Scanner;
import java.util.Arrays;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    String s=sc.nextLine();
	    int i,j, n=s.length();
	    for(i=0;i<n;i++);{
	        for(j=i;j<n;j++);{
	            String subs=s.substring(i,j+1);
	            char[] arr=subs.toCharArray();
	            Arrays.sort(arr);
	            System.out.println(new String(arr));
	        }
	    }
	}
}

