                                        // QUEUE
                                        
                                        // PriorityQueue 

// import java.util.*;
// class Sample implements Comparator{
//     public int compare(Object o1, Object o2){
//         Integer i1=(Integer)o1;
//         Integer i2=(Integer)o2;
//         return -i1.compareTo(i2);   // Decending order 
//     }
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 		PriorityQueue q=new PriorityQueue(new Sample());
// 		q.offer(40);
// 		q.offer(5);
// 		q.offer(12);
// 		q.offer(36);
// 		q.offer(24);
// 		System.out.println(q);
// 		System.out.println(q.poll());
// 		System.out.println(q.remove());
// 		System.out.println(q.poll());
// // 		System.out.println(q.remove());
// // 		System.out.println(q.poll());
// // 		System.out.println(q.remove());
// // 		System.out.println(q.peek());
// // 		System.out.println(q.element());
// 	}
// }


                                    // Deque
                                    
                                    // Array Deque
                                    
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		ArrayDeque q=new ArrayDeque();
		q.offerFirst(40);
		q.offerLast(5);
		q.offerFirst(5);
		q.offerFirst(36);
		q.offerFirst(24);
		q.offerLast(24);
		System.out.println(q);
// 		System.out.println(q.pollLast());
// 		System.out.println(q.removeFirst());
// 		System.out.println(q.poll());
// 		System.out.println(q.removeLast());
// 		System.out.println(q.pollLast());
// 		System.out.println(q.removeFirst());
		System.out.println(q.peek());
		System.out.println(q.peekLast());
		System.out.println(q.element());
		System.out.println(q.getFirst());
		System.out.println(q.getLast());
// 		System.out.println(q.removeFirstOcurrence(5));
// 		System.out.println(q.removeLastOcurrence(24));
		
	}
}
