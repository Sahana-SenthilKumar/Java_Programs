/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    
/*      Equal numbers or not

	    Scanner sc=new Scanner(System.in); 
		System.out.println("Enter two numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		if(a==b)
		    System.out.println("Number1 and Number2 are equal");
		else
		    System.out.println("Number1 and Number2 are not equal");
	
*/

/*      Odd or Even

        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a number");
		int a=sc.nextInt();
		if(a%2==0)
		    System.out.println(a+" is an even integer");
		else
		    System.out.println(a+" is an odd integer");

*/

/*      Positive or Negative number

        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a number");
		int a=sc.nextInt();
		if(a>=0)
		    System.out.println(a+" is a positive number");
		else
		    System.out.println(a+" is a negative number");
  
 
*/ 

/*      Leap year or not

        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter a year");
		int a=sc.nextInt();
		if(a%400==0)
		    System.out.println(a+" is a leap year");
		else if(a%100==0)
		    System.out.println(a+" is not a leap year");
		else if(a%4==0)
		    System.out.println(a+" is a leap year");
		else 
		    System.out.println(a+" is not a leap year");
 */
        
/*      Eligible to vote or not
	    
	    Scanner sc=new Scanner(System.in); 
		System.out.println("Enter your age");
		int a=sc.nextInt();
		if(a>=18)
		    System.out.println("Congratulation! You are eligible for casting your vote.");
		else
		    System.out.println("You are not eligible for casting your vote.");
 */ 
 
/*      m and n

        Scanner sc=new Scanner(System.in);
        int n;
		System.out.println("Enter an integer");
		int m=sc.nextInt();
		if(m>0)
		    n=1;
		else if(m==0)
		    n=0;
		else
		    n=-1;
		System.out.println("The value of n = "+n);
 */
 
/*      Person's Height

        Scanner sc=new Scanner(System.in);
        int n;
		System.out.println("Enter the person's height in centimeter");
		int m=sc.nextInt();
		if(m<150)
		    System.out.println("The person is Dwarf.");
		else if(m>=150 && m<175)
		    System.out.println("The person is Average.");
		else if(m>=175 && m<195) 
		    System.out.println("The person is Tall.");
		else
		    System.out.println("The person is Gaint.");
 */
 
 /*     Largest of 3 numbers
 
        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter three numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		if(a>b && a>c)
		    System.out.println("The 1st Number is the greatest among three");
		else if(b>c && b>c)
		    System.out.println("The 2nd Number is the greatest among three");
		else
		    System.out.println("The 3rd Number is the greatest among three");
  */	

/*      Quadrant

        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter two coordinates x and y");
		int x=sc.nextInt();
		int y=sc.nextInt();
		if(x>0 && y>0)
		    System.out.println("The coordinate point ("+x+","+y+") lies in the First quadrant.");
		else if(x<0 && y>0)
		    System.out.println("The coordinate point ("+x+","+y+") lies in the Second quadrant.");
		else if(x<0 && y<0)
		    System.out.println("The coordinate point ("+x+","+y+") lies in the Third quadrant.");
		else if(x>0 && y<0)
		    System.out.println("The coordinate point ("+x+","+y+") lies in the Forth quadrant.");
		else
		    System.out.println("The coordinate point ("+x+","+y+") lies in the Origin.");
 */
 
/*      Marks eligibility  

        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter the candidate's marks in Math, Physics and Chemistry in order");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		int total=(a+b+c);
		int cutoff=(a+b);
		if(a>=65 && b>=55 && c>=50 && total>=190 && cutoff>=140)
		    System.out.println("The candidate is eligible for admission.");
		else
		    System.out.println("The candidate is not eligible for admission.");
 */ 
 
/*      Quadratic equation roots

        Scanner sc=new Scanner(System.in); 
		System.out.println("Enter the a,b and c values for quadratic equation");
		double a=sc.nextDouble();
		double b=sc.nextDouble();
		double c=sc.nextDouble();
		double determinant=(b*b)-(4*a*c), root1, root2;
		if(determinant>0){
		    root1=(-b + Math.sqrt(determinant))/(2*a);
		    root2=(-b + Math.sqrt(determinant))/(2*a);
		    System.out.format("The roots %.5f and %.5f are real and different",root1,root2);
		}
		else if(determinant==0){
		    root1=(-b/(2*a));
		    root2=(-b/(2*a));
		    System.out.format("The roots %.5f and %.5f are real and equal",root1,root2);
		}
		else {
		   System.out.println("Root are imaginary; No solution."); 
		}   
 */
 

	}
}


