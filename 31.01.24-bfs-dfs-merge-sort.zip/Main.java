import java.util.*;
                            
                            
                                // BFS
                            
// public class Main
// {
// 	public static void main(String[] args) {
// 		ArrayList<ArrayList<Integer>> a=new ArrayList<ArrayList<Integer>>();
// 		for(int i=0; i<5; i++)
// 		    a.add(new ArrayList<Integer>());
		    
// 		    a.get(0).add(1);
// 		    a.get(0).add(2);
// 		    a.get(0).add(3);
// 		    a.get(1).add(0);
// 		    a.get(1).add(4);
// 		    a.get(2).add(0);
// 		    a.get(2).add(3);
// 		    a.get(3).add(0);
// 		    a.get(3).add(2);
// 		    a.get(3).add(4);
// 		    a.get(4).add(1);
// 		    a.get(4).add(3);
// 		//System.out.println(a);
		    
// 		boolean vis[]=new boolean[5];
// 		ArrayList<Integer> bfs=new ArrayList<Integer>();
// 		Queue<Integer> q=new LinkedList<Integer>();
// 		q.add(3);
// 		vis[3]=true;
// 		while(!q.isEmpty()){
// 		    Integer n=q.poll();
// 		    bfs.add(n);
// 		    for(Integer i : a.get(n)){
// 		        if(vis[i]==false){
// 		            vis[i]=true;
// 		            q.add(i);
// 		        }
// 		    }
// 		}
// 		System.out.println(bfs);
// 	}
// }


                                // DFS

// public class Main
// {
// 	public static void main(String[] args) {
// 		ArrayList<ArrayList<Integer>> a=new ArrayList<ArrayList<Integer>>();
// 		for(int i=0; i<6; i++)
// 		    a.add(new ArrayList<Integer>());
		    
// 		    a.get(0).add(1);
// 		    a.get(0).add(2);
// 		    a.get(1).add(0);
// 		    a.get(1).add(4);
// 		    a.get(2).add(0);
// 		    a.get(2).add(3);
// 		    a.get(3).add(2);
// 		    a.get(3).add(4);
// 		    a.get(4).add(1);
// 		    a.get(4).add(3);
// 		    a.get(4).add(5);
// 		    a.get(5).add(4);
// 		//System.out.println(a);
		    
// 		boolean vis[]=new boolean[6];
// 		ArrayList<Integer> dfs=new ArrayList<Integer>();
// 		Stack<Integer> q=new Stack<Integer>();
// 		q.add(0);
// 		vis[0]=true;
// 		while(!q.isEmpty()){
// 		    Integer n=q.pop();
// 		    dfs.add(n);
// 		    for(Integer i : a.get(n)){
// 		        if(vis[i]==false){
// 		            vis[i]=true;
// 		            q.add(i);
// 		        }
// 		    }
// 		}
// 		System.out.println(dfs);
// 	}
// }



                                // Merge

// public class Main{
//     public static void main (String[] args) {
//         int[] a={5,7,10,12,15,16,20,3,6,13,18,19};
//         int end=0, start=0;
//         for(int i=0; i<a.length; i++){
//             if(!(a[i]<a[i+1])){
//                 end=i;
//                 start=i+1;
//                 break;
            
//             }
//         }
//         int n=a.length-1;
//         merge(a,0,end,start,n);
//     }
//     public static void merge(int[] a, int i, int end, int j, int n){
//         int[] b=new int[a.length];
//         int k=0;
//         while(i<=end && j<=n){
//             if(a[i]<a[j]){
//                 b[k]=a[i];
//                 i++;
//             }
//             else{
//                 b[k]=a[j];
//                 j++;
//             }
//             k++;
//         }
//         while(i<=end){
//             b[k]=a[i];
//             k++;
//             i++;
//         }
//         while(j<=n){
//             b[k]=a[j];
//             k++;
//             j++;
//         }
        
//         for(int s : b)
//             System.out.print(s+" ");
//     }
    
//         //System.out.println(end+" "+start);
//         // for(int i=0; i<=end; i++){
//         //     for(int j=start; j<a.length; j++){
//         //         if(a[i]>a[j]){
//         //             int temp=a[i];
//         //             a[i]=a[j];
//         //             a[j]=temp;
//         //             b[i]=a[i];
//         //         }
//         //         else{
//         //             b[i]=a[i];
//         //         }
//         //     }
//         //     if(a[i]==a[end]){
//         //         for(int k=start; k<a.length; k++){
//         //         for(int s=k; s<a.length; s++){
//         //             if(a[k]>a[s]){
//         //                 int temp=a[k];
//         //                 a[k]=a[s];
//         //                 a[s]=temp;
//         //                 b[k]=a[k];
//         //             }
//         //             if(a[k]==a[a.length-1]){
//         //                 b[k]=a[k];
//         //             }
//         //         }
//         //     }
//         //     }
//         // }
        
// }





// public class Main{
//     public static void main (String[] args) {
//         int[] a={5,7,9,8,3,6,13,18,19};
//         int beg=0, end=a.length-1;
//         mergeSort(a, beg , end);
//         for(int s : a)
//             System.out.print(s+" ");    
//     }
//     public static void mergeSort(int[] a, int beg, int end){
//         if(beg<end){
//             int mid=(beg+end)/2;
//             mergeSort(a,beg,mid);
//             mergeSort(a,mid+1,end);
//             merge(a,beg,mid,end);
            
//         }
//     }
//     public static void merge(int[] a, int beg, int mid, int end){
        
//         int k,i,j;
//         int n1=mid-beg+1, n2=end-mid;
        
//         int list1[]=new int[n1];
//         int list2[]=new int[n2];
        
//         for(i=0; i<n1; i++)
//             list1[i]=a[beg+i];
//         for(j=0; j<n2; j++)
//             list2[j]=a[mid+1+j];
            
//         i=0;
//         j=0;
//         k=beg;
        
//          while(i<n1 && j<n2){
//             if(list1[i]<list2[j]){
//                 a[k]=list1[i];
//                 i++;
//             }
//             else{
//                 a[k]=list2[j];
//                 j++;
//             }
//             k++;
//         }
//         while(i<n1){
//             a[k]=list1[i];
//             k++;
//             i++;
//         }
//         while(j<n2){
//             a[k]=list2[j];
//             k++;
//             j++;
//         }
//     }
// }





