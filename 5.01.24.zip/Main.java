import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {

/*

    1. //Duplicate elements print
		
		int[] a=new int[20];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of terms :");
		int n=sc.nextInt();
		System.out.println("Enter the array elements :");
		for(int i=1;i<=n;i++){
		    a[i]=sc.nextInt();
		}
		System.out.print("Duplicate elements in the array : ");
		for(int i=0;i<n;i++){
		    for(int j=i+1;j<n;j++){
		        if(a[i]==a[j])
		            System.out.print(a[i]+" ");
		    }
		}
 
 */	
 
        int[] a=new int[20];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of terms :");
		int n=sc.nextInt();
		System.out.println("Enter the array elements :");
		for(int k=1;k<=n;k++){
		    a[k]=sc.nextInt();
		}
		int i,j,index=0;
// 		System.out.print("Duplicate elements in the array : ");
		for(i=0;i<n;i++){
		    for(j=i+1;j<n;j++){
		        if(a[i]==a[j]){
		            index=j;
		            System.out.print(j);
		        }
		    }
		}
		for(int s=index;s<n;s++){
		    a[s]=a[s+1];
		}
		for(int s=0;s<n;s++){
		    System.out.print(a[s]+" ");
		}
		
		
	
		
	}
}
