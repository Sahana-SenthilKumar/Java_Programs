/*


                                            // "FINAL" KEYWORD



    1.a. // final keyword
    
final class Hello
{
    final void display()
    {
        System.out.println("Hello Method");
    }
}
public class Main extends Hello     // Final class =>// Error: cannot inherit from final Hello
{
    void display()  // Final Method => // Error: display() in Main cannot override display() in Hello
    {
        System.out.println("Main Method");
    }
	public static void main(String[] args) {
	    final int a=10;
	    a=20;   //Final Variable => // Error: cannot assign a value to final variable a
	    Main m=new Main();
	    m.display();
		System.out.println("Hello World");
	}
}



    1.b. // final keyword
    
final class Hello
{
    final void display()
    {
        System.out.println("Hello Method");
    }
}
public class Main{  
    void display()  
    {
        System.out.println("Main Method");
    }
	public static void main(String[] args) {
	    final int a=10;
	    Main m=new Main();
	    m.display();
		System.out.println(a);
	}
}



                                            // "SUPER" KEYWORD
                                       
                                       
                                            
    2. // Super Constructor 
 
class Hello
{
    Hello()
    {
        System.out.println("Hello Constructor");
    }
    Hello(int a)
    {
        System.out.println(a);
    }
}
public class Main extends Hello
{
    Main()
    {
        super(10);
        // super(); // Having 'super();' is same as not having 'super();'' for non-argument specific call constructor;
        System.out.println("Main Constuctor");
        //super();  // Error: call to super must be first statement in constructor
    }
    void main()
    {
        //super();    // Error: call to super must be first statement in constructor
        System.out.println("Main Method");
    }
    public static void main(String[] args)
    {
        Main m=new Main();
        m.main();
    }
}



    3. // Super Variable
 
class Hello
{
    int a=10;
}
public class Main extends Hello
{
    int a=50;
    void display()
    {
        System.out.println(a);
        System.out.println(super.a);
    }
    public static void main(String[] args)
    {
        Main m=new Main();
        m.display();
    }
}


 
    4. // Super Method
 
class Hello
{
    void display()
    {
        System.out.println("Hello Method");
    }
}
public class Main extends Hello
{
    void display()
    {
        System.out.println("Main Method");
        super.display();
    }
    void displayMain()
    {
        super.display();
        System.out.println("Display Main Method");
    }
    public static void main(String[] args)
    {
        Main m=new Main();
        m.display();
        m.displayMain();
    }
}



    4.b. // Super Method  // 'super' is uded with only immediate parent  

class Hello
{
    void display()
    {
        System.out.println("Hello Method");
    }
}
class Bye extends Hello
{
    void display()
    {
        super.display();
        System.out.println("Bye Method");
        
    }
    void displayBye()
    {
        System.out.println("Display Bye Method");
        super.display();
    }
}
public class Main extends Bye
{
    void display()
    {
        System.out.println("Main Method");
        super.display();
    }
    public static void main(String[] args)
    {
        Main m=new Main();
        m.display();
        m.displayBye();
    }
}

 
 
                                             // INTERFACE
                                             
                                             
                                             
    5.a. // 1 Inetrface Method                                          
                                             
    interface A
    {
        void m1();
        void m2();
    }
    class Main implements A
    {
        // void m1()    // Error: m1() in Main cannot implement m1() in A
        public void m1()
        {
            System.out.println("m1");
        }
        public void m2()
        {
            System.out.println("m2");
        }
         public static void main(String[] args)
        {
            Main m=new Main();
            m.m1();
            m.m2();
        }
    }
    

   
    5.b. // 1 Inetrface Method                                          
                                             
    interface A
    {
        void m1();
        void m2();
    }
    abstract class Hello implements A
    {
        public void m1()
        {
            System.out.println("m1");
        }
    }
    class Main extends Hello
    {
        public void m2()
        {
            System.out.println("m2");
        }
         public static void main(String[] args)
        {
            Main m=new Main();
            m.m1();
            m.m2();
        }
    }
    
    
    
    //6.a. // 2 Inetrface Different Method                                          
                                             
    interface A
    {
        void m1();
    }
    interface B
    {
        void m2();
    }
    class Main implements A,B
    {
        public void m1()
        {
            System.out.println("m1");
        }
        public void m2()
        {
            System.out.println("m2");
        }
         public static void main(String[] args)
        {
            Main m=new Main();
            m.m1();
            m.m2();
        }
    }
    
    

    //6.b. // 2 Inetrface Same Method                                          
                                             
    interface A
    {
        void m1();
    }
    interface B
    {
        void m1();
    }
    class Main implements A,B
    {
        public void m1()
        {
            System.out.println("m1");
        }
         public static void main(String[] args)
        {
            Main m=new Main();
            m.m1();
        }
    }
    

    
    6.c.i) // 2 Interface extends
    
    interface A
    {
        void m1();
    }
    interface B extends A 
    {
        void m2();
    }
    class Main implements B
    // abstract class Main implements B     // To avoid the error below and also should extend another class for m1() method
    {
        // public void m1()     // Error: Main is not abstract and does not override abstract method m1() in A
        // {
        //     System.out.println("m1");
        // }
        public void m2()
        {
            System.out.println("m2");
        }
        public static void main(String[] args)
        {
            Main m=new Main();
            m.m1();
            m.m2();
        }
    }
    
    
    7. // Interface Variables
    
    interface A 
    {
        int a=10; 
        void m1();
    }
    class Main implements A 
    {
        // int a=20; // No Error cause 'a' is declared as a new variable => Output : 20
        public void m1()
        {
            // a=20;    // Error: cannot assign a value to final variable a
            System.out.println(a);
            //System.out.println(a++);  //  Error: cannot assign a value to final variable a
        }
        public static void main(String[] args)
        {
            Main m=new Main();
            m.m1();
        }
        
    }
    


    8. // Interface Variables : Ambiguity Problem
    
    interface A 
    {
        int a=10; 
        void m1();
    }
    interface B 
    {
        int a=30;
        void m1();
    }
    class Main implements A,B
    {
        public void m1()
        {
            //System.out.println(a);  // Error: reference to a is ambiguous
            System.out.println("m1");   // No Error as the variable is not used 
        }
        public static void main(String[] args)
        {
            Main m=new Main();
            m.m1();
        }
        
    }
    


    abstract class A 
    {
        A()
        {
            System.out.println("A constructor");
        }
        abstract void a()
        {
            print
        }
    }
    
    
*/


    
    
    
    
    