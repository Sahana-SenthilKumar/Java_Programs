import java.lang.Math;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
// 		int n=9;
// 		for (int i=1;i<=n;i++){
// 		    for( int j=1;j<=n;j++)
// 		        if(i==1 || i==n || j==1 || j==n)
// 		            System.out.print("5");
// 		        else{
// 		            if(i==2 || i==n-1 || j==n-1 || j==2)
// 		                System.out.print("4");
// 		            else
// 		                {
// 		                if(i==3 || i==n-2 || j==n-2 || j==3)
// 		                System.out.print("3");
// 		                else{
// 		                    if(i==4 || i==n-3 || j==n-3 || j==4)
// 		                    System.out.print("2");
// 		                    else{
// 		                      if(i==5 || i==n-4 || j==n-4 || j==5)
// 		                        System.out.print("1");
// 		                      else 
// 		                        System.out.print(" ");
// 		                    }
// 		                }
		                
		                
// 		                }
// 		        }
		        
		            
// 		System.out.println();
// 		}



        // int n=5;
        // for(int i=-n;i<=n;i++)
        // {
        //     if(i==0 || i==1)
        //         continue;
        //     for(int j=-n;j<=n;j++)
        //     {
        //         if(j==0 || j==1)
        //             continue;
        //         if(Math.abs(i)>=Math.abs(j))
        //             System.out.print(Math.abs(i));
        //         else
        //             System.out.print(Math.abs(j));
        //     }
        // System.out.println();
        // }
         
// 		int a[]=new int[6];
// 		int b[]=new int[6];
// 		Scanner sc=new Scanner(System.in);
// 		int sum=0, temp;
// 		System.out.println("Enter the elements of array a :");
// 		for(int i=0;i<a.length;i++)
// 		    a[i]=sc.nextInt();
// 		System.out.println("Enter the elements of array b :");
// 		for(int i=0;i<b.length;i++)
// 		    b[i]=sc.nextInt();
		    
		    
// 		for(int i=0;i<a.length;i++)
// 		    System.out.print("The  array is : ")    


// 		for(int i=0;i<a.length;i++)    
// 		    sum=sum+a[i];
// 		System.out.print("Sum of array : "+sum);


//      System.out.println("Even position elements of array :");		
// 		for(int i=0;i<a.length;i++)
// 		    if(i%2!=0)
// 		        System.out.print(a[i]+" ");


//      ystem.out.println("Odd index elements of array :");
// 		for(int i=0;i<a.length;i++)
// 		    if(i%2!=0)
// 		        System.out.print(a[i]+" ");


//       System.out.print("The even elements of array : ");		        
// 		 for(int i=0;i<a.length;i++)
//             if(a[i]%2==0)
// 		        System.out.print(a[i]+" ");


        // System.out.print("The odd elements of array : ");
        // for(int i=0;i<a.length;i++)
        //     if(a[i]%2!=0)
        //          System.out.print(a[i]+" ");
          
                 
    //   System.out.print("Even elements followed by odd elements of array : ");
    //     for(int i=0;i<a.length;i++)
    //         if(a[i]%2==0)
    //              System.out.print(a[i]+" ");
    //     for(int i=0;i<a.length;i++)
    //         if(a[i]%2!=0)
    //              System.out.print(a[i]+" ");
           
                 
        // System.out.print("Odd index elements followed by Even position elements of array : ");
        // for(int i=0;i<a.length;i++)
        //     if(i%2!=0)
        //          System.out.print(a[i]+" ");
        // for(int i=0;i<a.length;i++)
        //     if(i%2!=0)
        //          System.out.print(a[i]+" ");
        
        
        // System.out.print("Reverse of the array : ");
        // for(int i=a.length-1;i>=0;i--)
        //     System.out.print(a[i]+" ");
        
        
        // System.out.print("Reverse of the array by first half and seconf half  : ");
        // int l=a.length/2;
        // for(int i=l-1;i>=0;i--){
        //     System.out.print(a[i]+" ");
        // }
        // for(int i=a.length-1;i>=l;i--){
        //     System.out.print(a[i]+" ");
        // }
        
        
//         for(int i=0;i<a.length;i++) 
//             if(a[i]%2==0)
// 		        sum=sum+a[i];
// 		System.out.print("Sum of even array elements : "+sum);


        // System.out.print("Swap of 1st & 2nd; 3rd and 4th and so on elements of array : ");
        // int[] a={1,2,3,4,5,6};
        // for(int i=0;i<a.length;i++){
        // if(a.length%2!=0){
        //     if(i==a.length-1)
        //         System.out.print(a[i]+" ");
        //     else
        //         if(i%2==0)
        //         System.out.print(a[i+1]+" "+a[i]+" ");
        // }
        // else{
        //     if(i%2==0)
        //         System.out.print(a[i+1]+" "+a[i]+" ");
        //  }
        // }
        
        
        // int[] a={1,2,3};
        // int[] b={1,2,3};
        // int[] sum=new int[a.length];
        // if(a.length==b.length){
        //     for(int i=0;i<a.length;i++)
        //             sum[i]=a[i]+b[i];
        // System.out.print("Sum of two arrays : ");
        // for(int i: sum)
        //     System.out.print(i+" ");
                
        // }
        
        
        // int[] a={1,2,3,45,12,34};
        // int large=a[0], temp;
        // for(int i=0;i<a.length;i++){
        //     if(a[i]>large){
        //         temp=large;
        //         large=a[i];    
        // }
        //         
        // }
        // System.out.println("Largest array element : "+large);
        // System.out.println("2nd Largest array element : "+temp);
        
        // int[] a={1,2,3,45,12,34,0};
        // int small=a[0];
        // for(int i=0;i<a.length;i++){
        //     if(a[i]<small)
        //         small=a[i];
        // }
        // System.out.println("Smallest array element : "+small);
        
        // int[] a={1,2,3,45,12,34};
        // int temp;
        // for(int i=0;i<a.length;i++){
        //     for(int j=i+1;j<a.length;j++) 
        //         if(a[j]<a[i]){
        //             temp=a[i];
        //             a[i]=a[j];
        //             a[j]=temp;
        //         }
        // }
        // System.out.println("2nd Largest array element : "+a[a.length-2]);
        
        // int[] a={1,2,3,45,12,34,0};
        // int temp;
        // for(int i=0;i<a.length;i++){
        //     for(int j=i+1;j<a.length;j++) 
        //         if(a[j]<a[i]){
        //             temp=a[i];
        //             a[i]=a[j];
        //             a[j]=temp;
        //         }
        // }
        // System.out.println("2nd Smallest array element : "+a[1]);
        
        // int[] a={11,12,13,14,15,16,17};
        // int[] b={3,4,5,6,7,8,9};
        // int[] c=new int[a.length+b.length];
        // int[] even=new int[c.length];
        // int[] odd=new int[c.length];
        // for(int i=0;i<a.length;i++)
        //     c[i]=a[i];
        // for(int i=0;i<b.length;i++)
        //     c[a.length+i]=b[i];
        
        // for(int i=0;i<c.length;i++){
        // if(c[i]%2==0)
        //     even[i]=c[i];
        // else
        //     odd[i]=c[i];
        // }
        
        // System.out.println("Even array");
        // for(int i: even)
        //     System.out.print(i+" ");
        // System.out.println();
        // System.out.println("Odd array");
        // for(int i: odd)
        //     System.out.print(i+" ");
    
        int[] a={1,46,555,6,23,4,566,89,897,56};
        int count1d, count2d, count3d;
        for(int i=0;i<a.length)
        
        

        
        
        
	}
}
