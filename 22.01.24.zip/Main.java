// public class Main
// {
// 	public static void main(String[] args) {
// 		String s="1ab34j6";
// 		int sum=0, tot=0;
		
// // 		for(char ch : s.toCharArray()){
// // 		    if('0'<=ch && ch<='9'){
// // 		        sum=sum+(ch-'0');
// // 		    }
// // 		}


// //         String[] i=s.split("[^0-9]+");
// // 	    for(String ch : i){
// // 	        System.out.println(ch);
// // 	    }
// // 	   for(int j=0; j<i.length; j++){
// // 	   if(!i[j].isEmpty())
// // 	      sum+=Integer.parseInt(i[j]);
// // 	   }
// // 	   System.out.println(sum);

//         for(int i=0; i<s.length(); i++){
//             if(s.charAt(i)>='0' && s.charAt(i)<='9' )
//                 sum=sum*10+(s.charAt(i)-'0');
//             else{
//                 tot=tot+sum;
//                 sum=0;
//             }
//         } 
//         if(sum!=0){
//             tot=tot+sum;
            
//         }
//         System.out.println(tot);
// 	}
// }

// public class Main{
//     public static void main(String args[]){
//         String s="23GF";
//         int sum=0;
//         char[] a=s.toCharArray();
//         int n=a.length-1;
//         for(int i=0; i<=n; i++ ){
//             if(a[i]>='0' && a[i]<='9'){
//                 sum=sum+((a[i]-'0')*(int)Math.pow(17,(n-i)));
//             }
//             else if(a[i]>='A' && a[i]<='G'){
//                 sum=sum+((a[i]-55)*(int)Math.pow(17,(n-i)));
//             }
//         }
//         System.out.println(sum);
//     }
// }


// public class Main{
//     public static void main (String[] args) {
//         int n=10;
//         StringBuilder s=new StringBuilder();
//         while(n!=0){
//             int rem=n%2;
//             s.append(rem);
//             n=n/2;
//         }
//         s.reverse();
//         int count=0, sum=0;
//         int k=Integer.parseInt(s.toString());
//         while(k>0){
//             int rem=k%10;
//             k=k/10;
//             if(rem==0){
//                 sum=sum+(int)Math.pow(2,count);
//             }
//             count++;
//         }
//         System.out.println(sum);
        
//     }
// }


// public class Main{
//     public static void main (String[] args) {
//         int[] a={3,4,5,8,9};
//         int count=1;
//         boolean condition=false;
//         for(int i=1; i<a.length; i++){
//             for(int j=0; j<i; j++){
//                 if(a[j]<a[i]){
//                     condition = true;
//                 }
//                 else{
//                     condition = false;
//                 }
//             }
//             if(condition)
//                 count++;
//         }
//         System.out.println(count);
//     }
// }


// public class Main{
//     public static void main (String[] args) {
//         int[] a={2,5,7,8,9,4};
//         int odd=0, even=0;
//         for(int i=0; i<a.length;i++){
//             if(a[i]%2==0){
//                 even++;
//             }
//             else
//                 odd++;
//         }
//         System.out.println("ODD : "+(odd*200));
//         System.out.println("EVEN : "+(even*300));
//     }
// }


// public class Main {
//     public static void main(String[] args) {
//         String s = "mon";
//         s = s.toLowerCase();
//         int sun = 0;
//         int n = 13;
//         int i = 0;

//         while (i < n) {
//             if (s.equals("mon")) {
//                 if (i + 6 <= n) {
//                     i += 6;
//                 } else {
//                     break;  
//                 }
//             } else if (s.equals("tue")) {
//                 if (i + 5 <= n) {
//                     i += 5;
//                 } else {
//                     break;
//                 }
//             } else if (s.equals("wed")) {
//                 if (i + 4 <= n) {
//                     i += 4;
//                 } else {
//                     break;
//                 }
//             } else if (s.equals("thu")) {
//                 if (i + 3 <= n) {
//                     i += 3;
//                 } else {
//                     break;
//                 }
//             } else if (s.equals("fri")) {
//                 if (i + 2 <= n) {
//                     i += 2;
//                 } else {
//                     break;
//                 }
//             } else if (s.equals("sat")) {
//                 if (i + 1 <= n) {
//                     i += 1;
//                 } else {
//                     break;
//                 }
//             } else if (s.equals("sun")) {
//                 if (i + 7 <= n) {
//                     i += 7;
//                 } else {
//                     break;
//                 }
//             }
//             s = "sun";
//             sun++;
//         }
//         System.out.println(sun);
//     }
// }


// public class Main{
//     public static void main (String[] args) {
//         int n=5, temp=n, k=0;
//         String s="aabaababbaaaabbb";
//         int y=(int)Math.ceil((double)s.length() / n);
//         System.out.println(y);
//         String[] a=new String[y];
//         for(int i=0; i<y;i++){
//             if (n > s.length()) {
//                 n = s.length();
//             }
//             a[i]=s.substring(k, n);
//             System.out.println(a[i]);
//             k+=temp;
//             n+=temp;
//         }
//         int count=0, max=0, sub=0;
//         for(int i=0; i<y;i++){
//             for(int j=0; j<a[i].length(); j++){
//                 if(a[i].charAt(j)=='a'){
//                     count++;
//                 }
//             }
//             if(count>max){
//                 max=count;
//                 sub=i;
                
//             }
//             count=0;
//         }
//         System.out.println(a[sub]+" "+max);
//     }
// }

