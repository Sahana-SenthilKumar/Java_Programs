
public class Main
{
	public static void main(String[] args) {
	    String s="abbaca";
		char[] a = s.toCharArray();
        int n = a.length;
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < n; i++) {
            if(i < n -1 ){
                //System.out.println(i);
                while( a[i] == a[i + 1]) {
                    a[i]=a[i+2];
                    a[i+1]=a[i+3];
                    n-=2;
                }
             
            } else {
                result.append(a[i]);
            }
        }
        System.out.println(result.toString());
	}
}
