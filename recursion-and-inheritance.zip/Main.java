import java.util.Scanner;
public class Main
{
	
/*
    1. //Fibonacci
    
        public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        int n1=0,n2=1,n3;
        System.out.println("Fibonacci Series upto "+n+" terms :");
        for(int i=1; i<=n;i++){
            System.out.print(n1+" ");
            n3=n1+n2;
            n1=n2;
            n2=n3;
        }
        
    2.a. //Fibonacci using Recursive Function
        
    int a=0,b=1;
    int fib(int x){
        int c=0;
        if(x>0){
            c=a+b;
            a=b;
            b=c;
            System.out.print(c+" ");
            fib(x-1);
        }
        return 1;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        System.out.println("Fibonacci Series upto "+n+" terms :");
        int a=0,b=1;
        System.out.print(a+" "+b+" ");
        Main m=new Main();
        m.fib(n-2);
     
    
    2.b. //Fibonacci using Recursive Function  
       
    static int a=0,b=1,c;
    static void fib(int x){
        if(x>0){
            System.out.print(a+" ");
            c=a+b;
            a=b;
            b=c;
            fib(x-1);
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Main m=new Main();
        System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        System.out.println("Fibonacci Series upto "+n+" terms :");
        m.fib(n);
        
*/ 
        
	}
}
