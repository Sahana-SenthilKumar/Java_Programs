import java.util.*;
// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main{
//     public static boolean Order(Node root,int ele){
//         if(root == null)
//             return false;
//         if(root.key==ele)
//             return true;
//         if(Order(root.left, ele) || Order(root.right, ele))
//             return true;
//         else
//             return false;
//     }
//     public static void main (String[] args) {
//         Node n=new Node(10);
//         n.left=new Node(50);
//         n.right=new Node(75);
//         n.left.left=new Node(20);
//         n.left.right=new Node(25);
//         n.right.left=new Node(80);
//         n.right.right=new Node(20);
//         int ele=10;
//         boolean s=Order(n, ele);
//         if(s){
//             System.out.println("True");
//         }
//         else    
//             System.out.println("False");
//     }
// }


// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main{
//     public static ArrayList<Integer> Order(Node root, ArrayList<Integer> path, int ele){
//         if(root == null){
//             return path;
//         }
//         path.add(root.key); 
//         if(root.key==ele){
//             //System.out.println(path);
//             return path;
//         }
//         else{
//             Order(root.left, path, ele);
//             if(path.contains(ele))
//                 return path;
//             else{
//                 Order(root.right, path, ele);
//                 if(!path.contains(ele))
//                     path.remove(path.size()-1);
//                 // else    
//                 //     return path;
//         }
//         }
            
//         return path;
//     }
//     public static void main (String[] args) {
//         Node n=new Node(10);
//         n.left=new Node(50);
//         n.right=new Node(75);
//         n.left.left=new Node(20);
//         n.left.right=new Node(25);
//         n.right.left=new Node(80);
//         n.right.right=new Node(30);
//         int ele=30;
//         ArrayList<Integer> path=new ArrayList<>();
//         System.out.println(Order(n, path, ele));
//         //Order(n, path, ele);
//     }
// }


// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main{
//     public static ArrayList<Integer> LCA(Node root, ArrayList<Integer> path, int ele){
//         if(root == null){
//             return path;
//         }
//         path.add(root.key); 
//         if(root.key==ele){
//             //System.out.println(path);
//             return path;
//         }
//         else{
//             LCA(root.left, path, ele);
//             if(path.contains(ele))
//                 return path;
//             else{
//                 LCA(root.right, path, ele);
//                 if(!path.contains(ele))
//                     path.remove(path.size()-1);
//             }
//         }
//         return path;
//     }
//     public static void main (String[] args) {
//         Node n=new Node(10);
//         n.left=new Node(50);
//         n.right=new Node(75);
//         n.left.left=new Node(20);
//         n.left.right=new Node(25);
//         n.right.left=new Node(80);
//         n.right.right=new Node(30);
//         n.left.left.left=new Node(15);
//         int ele=25, ele1=15;
//         ArrayList<Integer> path=new ArrayList<>();
//         ArrayList<Integer> path1=new ArrayList<>();
//         ArrayList<Integer> s=LCA(n, path, ele);
//         ArrayList<Integer> s1=LCA(n, path1, ele1);
//         int min=Math.min(s.size(),s1.size());
//         Integer lca=0;
//         for(int i=0; i<min; i++){
//             if(s.get(i)==s1.get(i))
//                 lca=s.get(i);
//         }
//         System.out.println(lca);
//     }
    
// }



// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main{
//     public static int Height(Node root){
//         int height=0;
//         if()
//     }
//     public static void main (String[] args) {
//         Node n=new Node(10);
//         n.left=new Node(50);
//         n.right=new Node(75);
//         n.left.left=new Node(20);
//         n.left.right=new Node(25);
//         n.right.left=new Node(80);
//         n.right.right=new Node(30);
//         n.left.left.left=new Node(15);
//         System.out.println(Height(n));
        
//     }
// }



// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main{
//     public static boolean Identical(Node root1, Node root2){
//         if(root1==null && root2==null)
//             return true;
//         if(root1!=null && root2!=null){
//             return (root1.key==root2.key && Identical(root1.left, root2.left) 
//             && Identical(root1.right, root2.right));
//         }
//         return false;
//     }
//     public static void main (String[] args) {
//         Node n=new Node(5);
//         n.left=new Node(10);
//         n.right=new Node(15);
//         n.left.left=new Node(20);
//         n.left.right=new Node(25);
//         n.right.left=new Node(30);
//         n.right.right=new Node(35);
        
//         Node n1=new Node(5);
//         n1.left=new Node(10);
//         n1.right=new Node(75);
//         n1.left.left=new Node(20);
//         n1.left.right=new Node(25);
//         n1.right.left=new Node(30);
//         n1.right.right=new Node(35);
        
//         System.out.println(Identical(n,n1));
//     }
// }



// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main{
//     public static boolean Mirror(Node root1, Node root2){
//         if(root1==null && root2==null)
//             return true;
//         if(root1!=null && root2!=null){
//             return (root1.key==root2.key && Mirror(root1.left, root2.right) 
//             && Mirror(root1.right, root2.left));
//         }
//         return false;
//     }
//     public static void main (String[] args) {
//         Node n=new Node(5);
//         n.left=new Node(10);
//         n.right=new Node(15);
//         n.right.left=new Node(35);
//         n.right.right=new Node(45);

        
//         Node n1=new Node(5);
//         n1.left=new Node(15);
//         n1.right=new Node(10);
//         n1.left.right=new Node(35);
//         n1.left.left=new Node(45);
        
//         System.out.println(Mirror(n,n1));
//     }
// }


// class Node{
//     int key;
//     Node left;
//     Node right;
//     Node(int key){
//         this.key=key;
//         this.left=null;
//         this.right=null;
//     }
// }
// public class Main{
//     public static boolean Symetric(Node root, Node root1){
//         if(root==null && root1==null )
//             return true;
//         if(root!=null && root1!=null){
//             return (root.key==root1.key && Symetric(root.left, root1.right)
//             && Symetric(root.right, root1.left));
//         }
//         return false;
//     }
//     public static void main (String[] args) {
//         Node n=new Node(5);
//         n.left=new Node(10);
//         n.right=new Node(10);
//         //n.left.left=new Node(35);
//         n.left.right=new Node(45);
//         //n.right.left=new Node(45);
//         n.right.right=new Node(45);
//         //n.left.right.left=new Node(95);
//         //n.right.left.right=new Node(95);

        
//         System.out.println(Symetric(n,n));
//     }
// }