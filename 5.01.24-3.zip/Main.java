/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// import java.util.Scanner;
// public class Main
// {
// 	public static void main(String[] args) {

//         int[] a={10,50,10,40,10};
// 		int i,j,index=0, m=0, n=a.length, count=0;

// 		for(i=0;i<n;i++){
// 		    for(j=0;j<n;j++){
// 		        if (i!=j && a[i]==a[j]){
// 		            count++;
// 		            a[i]=a[i+1];
// 		        }
// 		    }
// 		}
// 		System.out.println();
// // 		for(int s=index;s<n-1;s++){
// // 		    a[s]=a[s+1];
// // 		n--;
// 		for(int s=0;s<n-count;s++){
// 		    System.out.print(a[s]+" ");
// 		}
// 	}
// }




// import java.util.Scanner;
// public class Main
// {
// 	public static void main(String[] args) {

//         int[] a={20,50,20,70,20};
// 		int i,j,index=0, m=0, n=a.length, count=0;
// 		for(i=0;i<n;i++){
// 		    if(i==0){
// 		        for(j=i+1;j<n;j++){
// 		            if(a[i]==a[j]){
// 		                //System.out.print(j);
// 		                while(j<n-1){
// 		                a[j]=a[j+1];
// 		                System.out.println(a[j]);
// 		                j++;
// 		                }
// 		                n-=1;
// 		                System.out.print(n);
// 		            }
// 		        }
// 		    }
	
// 		}
// 		System.out.println();
// 		for(int k=0;k<n;k++){
// 		    System.out.print(a[k]+" ");
// 		}
// 	}
// }

// public class Main {
//     public static void main(String[] args) {
//         int[] array = {20, 50, 20, 70, 20};

//         System.out.println("Original Array:");
//         printArray(array);

//         int[] resultArray = removeDuplicates(array);

//         System.out.println("\nArray after removing duplicates:");
//         printArray(resultArray);
//     }

//     public static int[] removeDuplicates(int[] array) {
//         int n = array.length;

//         // Count the occurrences of each element
//         for (int i = 0; i < n; i++) {
//             for (int j = i + 1; j < n; j++) {
//                 if (array[i] == array[j]) {
//                     // Shift elements to the left to fill the gap
//                     for (int k = j; k < n - 1; k++) {
//                         array[k] = array[k + 1];
//                     }
//                     n--; // Decrease the size of the array
//                     j--; // Adjust the index for the next iteration
//                 }
//             }
//         }

//         // Create a new array with the unique elements
//         int[] resultArray = new int[n];
//         System.arraycopy(array, 0, resultArray, 0, n);

//         return resultArray;
//     }

//     public static void printArray(int[] array) {
//         for (int element : array) {
//             System.out.print(element + " ");
//         }
//         System.out.println();
//     }
// }

// public class Main{
//     public static void main(String[] args){
//         int[] a={10,40,10,50,10,10,10,70,80};
//         int n=a.length,i,j;
//         for(i=0;i<n;i++){
//             for(j=i+1;j<n;j++)
//             {
        
//                 if(a[i]==a[j]){
//                     for(int k=j;k<n-1;k++){
//                         a[k]=a[k+1];
//                     }
//                     n--;
//                     j--;
                    
//                 }
//             }
//         }
//         for(int k=0;k<n;k++){
//             System.out.print(a[k]+" ");
//         }
        
        
// public class Main{
//     public static void main(String[] args){
//         int[] a={5,3,1,9,8,2,4,7};
//         int n=a.length, p=a[0], temp;
//         for(int i=0;i<n; ){
//             for(int j=n;j>0; ){
//                 if(a[i]<=p){
//                     i++;
//                 }
//                 else if(a[j]>p){
//                     j--;
//                 }
//                 else if(i<j){
//                     temp=i;
//                     i=j;
//                     j=temp;
//                 }
//                 else{
//                     temp=j;
//                     j=p;
//                     p=temp;
//                 }
//             }
//         }
//         for(int i=0;i<n;i++){
//             System.out.print(a[i]+" ");
//         }
//     }
// }    
        
        
public class Main {
    public static void main(String[] args) {
        int[] a = {5, 3, 1, 9, 8, 2, 4, 7};
        quickSort(a, 0, a.length - 1);
        
        System.out.println("Sorted Array:");
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
    }

    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(arr, low, high);
            quickSort(arr, low, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, high);
        }
    }

    public static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;

        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }
}

        
        
        
        
        
        
        
        
        
        
        
 