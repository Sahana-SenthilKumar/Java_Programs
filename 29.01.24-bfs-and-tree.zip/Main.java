import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
	    
// 		ArrayList<ArrayList<Integer>> a=new ArrayList<ArrayList<Integer>>();
// 		for(int i=0; i<5; i++){
//             a.add(new ArrayList<Integer>());
//         }
//         a.get(0).add(2);
// 		a.get(0).add(3);
// 		a.get(0).add(4);
// 		a.get(1).add(2);
// 		a.get(2).add(0);
// 		a.get(2).add(1);
// 		a.get(3).add(0);
// 		a.get(3).add(4);
// 		a.get(4).add(0);
// 		a.get(4).add(3);

// //         ArrayList<ArrayList<Integer>> a[]=new ArrayList[5];
        
        
// //         for(int i=0; i<5; i++)
// //             a[i]=new ArrayList();
        
// //         // a[0]=new ArrayList();
// //         // a[1]=new ArrayList();
// //         // a[2]=new ArrayList();
// //         // a[3]=new ArrayList();
// //         // a[4]=new ArrayList();
       
// //       ArrayList al=a[0];
// // 		al.add(2);
// // 		al.add(3);
// // 		al.add(4);
		
// // 		al=a[1];
// // 		al.add(2);
		
// // 		al=a[2];
// // 		al.add(0);
// // 		al.add(1);
		
// // 		al=a[3];
// // 		al.add(0);
// // 		al.add(4);
		
// // 		al=a[4];
// // 		al.add(0);
// // 		al.add(3);
		
// 		//System.out.println(a[0].get(0));
		
// // 		for(int i=0; i<5; i++)
// // 		    System.out.println(a[i]);
		    
// 	    ArrayList<Integer> bfs=new ArrayList<>();
// 	    boolean vis[]=new boolean[5];
// 	    Queue<Integer> q=new LinkedList<>();
// 	    q.add(0);
// 	    vis[0]=true;
	    
// 	    while(!q.isEmpty()){
// 	        Integer node=q.poll();
// 	        bfs.add(node);
	        
// 	        for(Integer i : a.get(node)){
// 	            if(vis[i]==false){
// 	                vis[i]=true;
// 	                q.add(i);
// 	            }
// 	        }
// 	    }
	    
// 		System.out.println(bfs);    
// 	}
// }

class Node{
    int key;
    Node left;
    Node right;
    Node(int key){
        this.key=key;
        this.left=null;
        this.right=null;
    }
}
public class Main{
    public static void Order(Node root){
        if(root==null)
            return;
        //System.out.print(root.key+" ");   //Oreorder
        Order(root.left);
        System.out.print(root.key+" "); //Inorder
        Order(root.right);
        //System.out.print(root.key+" ");   //Postorder
    }
    public static void main (String[] args) {
        Node n=new Node(5);
        n.left=new Node(10);
        n.right=new Node(15);
        n.left.left=new Node(20);
        n.left.right=new Node(25);
        n.right.left=new Node(30);
        n.right.right=new Node(35);
        
        Order(n);
    }
}

import java.io.*;
import java.util.*;
class Main{
public static int Sub(int[] arr,int i,ArrayList<Integer> path, int sum)
{
    int count=2;
	if(i==arr.length)
	{
		if (sum==6)
			count++;
	}
	else
	{
		
		path.add(arr[i]);
		sum+=arr[i];
		Sub(arr, i + 1, path, sum);
		path.remove(path.size() - 1);
		sum-=arr[i];
		Sub(arr, i + 1, path, sum);
	}
	return count;
	
}
public static void main(String[] args)
{
	int[] arr={1, 2, 3, 4};
	int sum=0;
	ArrayList<Integer> path=new ArrayList<>();
    System.out.println(Sub(arr, 0, path, sum));
    
}
}
