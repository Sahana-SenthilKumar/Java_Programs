import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    

/*
        1. //Sum of matrix element

		int r,c,i,j, sum=0;
		int[][] a=new int[5][5];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of rows : ");
		r=sc.nextInt();
		System.out.println("Enter the number of cols : ");
		c=sc.nextInt();
		System.out.println("Enter the elements of matrix : ");
		for(i=0;i<r;i++){
	       for(j=0;j<c;j++){
	               a[i][j]=sc.nextInt();
	           }
	       }
	    for(i=0;i<r;i++){
	       for(j=0;j<c;j++){
	               sum+=a[i][j];
	           }
	       }
		System.out.println("Sum of Matrix elements : "+sum);
	
	
	    2. //Sum of rows
 */
 
        int r,c,i,j, sum=0;
		int[][] a=new int[5][5];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of rows : ");
		r=sc.nextInt();
		System.out.println("Enter the number of cols : ");
		c=sc.nextInt();
		System.out.println("Enter the elements of matrix : ");
		for(i=0;i<r;i++){
	       for(j=0;j<c;j++){
	               a[i][j]=sc.nextInt();
	           }
	       }
	    for(i=0;i<r;i++){
	       for(j=0;j<c;j++){
	               sum+=a[i][j];
	           }
	       }
		System.out.println("Sum of Matrix elements : "+sum);

	}
}
