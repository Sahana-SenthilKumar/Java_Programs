import java.util.Scanner;
import java.lang.Math;
import java.util.Arrays;        
public class Main
{
	public static void main(String[] args) {
	
	
	
	
	
	                                        // EXPECTION HANDLING
	//  ERROR  
	
	
// public class Main{
// public static void main(String[] args){
// int[] a=new int[2147483647];
// }
// }

    
    // EXCEPTION


// public class Main1{
// public static void main(String[] args){
// System.out.println(30/0);
// }
// }

    // 1.
    
    
// public class Exp1{
// public static void main(String[] args){
// try{
// System.out.println("Hello");
// System.out.println(30/0);
// System.out.println("Hai");
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// }
// }

    
    // 2.
    
    
// public class Exp2{
// public static void main(String[] args){
// try{
// System.out.println("Hello");
// System.out.println(30/5);
// System.out.println("Hai");
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// }
// }
	                                        
    // 3.
    
    
// public class Exp3{
// public static void main(String[] args){
// System.out.println("Hello");
// try{
// System.out.println(30/0);
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// System.out.println("Hai");
// }
// }


    // 4.


// public class Exp4{
// public static void main(String[] args){
// one();
// }
// public static void one(){
// two();
// }
// public static void two(){
// System.out.println("Hello");
// System.out.println(30/0);
// }
// }    
    
    // 5.


// public class Exp5{
// public static void main(String[] args){
// one();
// System.out.println(30/0);
// }
// public static void one(){
// two();
// }
// public static void two(){
// System.out.println("Hello");
// }
// }
    
    // 6.
    
    
// public class Exp6{
// public static void main(String[] args){
// try{
// System.out.println(30/0);
// }
// catch(Exception e){
// System.out.println("In catch");
// e.printStackTrace();
// }
// }
// }

//     // 7.


// public class Exp7{
// public static void main(String[] args){
// try{
// System.out.println(30/0);
// }
// catch(Exception e){
// System.out.println("In catch");
// System.out.println(e.toString());
// //e.toString();
// }
// }
// }    
    
//     // 8.


// public class Exp8{
// public static void main(String[] args){
// try{
// System.out.println(30/0);
// }
// catch(Exception e){
// System.out.println("In catch");
// System.out.println(e.getMessage());
// }
// }
// }    
    
//     // 9.


// public class Exp9{
// public static void main(String[] args){
// try{
// System.out.println(30/0);
// //FileReader f=new FileReader("abc.txt");
// }
// catch(ArithmeticException e){
// System.out.println("In ArithmeticException");
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// }
// }    
    
//     // 10.


// public class Exp10{
// public static void main(String[] args){
// try{
// //System.out.println(30/0);
// FileReader fr=new FileReader("abc.txt");
// }
// catch(ArithmeticException e){
// System.out.println("In ArithmeticException");
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// }
// }    
    
//     // 11.


// public class Exp11{
// public static void main(String[] args){
// try{
// System.out.println(30/0);
// }
// catch(ArithmeticException e){
// System.out.println("In ArithmeticException");
// }
// catch(ArithmeticException e){
// System.out.println("In catch");
// }
// }
// }    
    
    // 12.


// public class Exp12{
// public static void main(String[] args){
// try{
// System.out.println(30/0);
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// catch(ArithmeticException e){
// System.out.println("In ArithmeticException");
// }
// }
// }    
    
    // 13.                                       
	            
	                                         
// import java.sql.SQLException;
// public class Exp13{
// public static void main(String[] args){
// try{
// System.out.println(30/0);
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// catch(SQLException e){
// System.out.println("In IOException");
// }
// }
// }


    // 15.
    
    	                                        
// import java.sql.SQLException;
// public class Exp15{
// public static void main(String[] args){
// try{
// System.out.println(30/0);
// }
// catch(SQLException e){
// System.out.println("In IOException");
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// }
// }	

    // 16. // finally
    
    
// public class Exp16{
// public static void main(String[] args){
// try{
// System.out.println(30/0);
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// finally{
// System.out.println("In finally");
// }
// }
// }

    
    // 17. // finally
    
    
// public class Exp17{
// public static void main(String[] args){
// try{
// System.out.println(30/5);
// }
// catch(Exception e){
// System.out.println("In catch");
// }
// finally{
// System.out.println("In finally");
// }
// }
// }


    // 18. // 
    
    
// public class Exp18 extends RuntimeException{
// public static void main(String[] args){
// int age=17;
// if(age<18){
// throw new Exp18();
// }
// else{
// System.out.println("Valid Age");
// }
// }
// }


    // 19. // throw
    
    
// public class Exp19 extends RuntimeException{
// public static void main(String[] args){
// int age=17;
// if(age<18){
// throw new ArithmeticException("Invalid");
// }
// else{
// System.out.println("Valid Age");
// }
// }
// }


    // 20. // throws
    
    
//     public class Exp20 {
//     public static void main(String[] args) {
//         try {
//             one();
//         } catch (ArithmeticException e) {
//             System.out.println("Caught ArithmeticException in catch");
//         }
//     }

//     static void one() throws ArithmeticException {
//         System.out.println(30 / 0);
//     }
// }


    // 21. // throws
    
    
// public class Exp21
// {
// public static void main(String[] args) throws ArithmeticException
// {
// System.out.println(30/0);  
// }
// }







	}
}
