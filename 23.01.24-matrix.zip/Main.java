// public class Main
// {
// 	public static void main(String[] args) {
//     int[] a={15,2,-2,-8,7,1,9,5,6};
//     int max=0;
//     for(int i=0; i<a.length; i++){
//         int sum=0;
//         for(int j=i; j<a.length; j++){
//             sum+=a[j];
//             if(sum==0){
//                 max=Math.max(max,j-i+1);
//             }
//         }
//     }
//     System.out.println(max);

// 	}
// }


// public class Main{
//     public static void main (String[] args) {
//         int l=1;
//         int u=100;
//         int x=9;
//         int count=0;
//         for(int i=l; i<=u; i++){
//             int temp=i;
//             while(temp!=0){
//                 if(temp%10==x){
//                     count++;
//                 }
//                 temp=temp/10;
                
//             }
//         }
        
//         System.out.println(count);
//     }
// }

// public class Main{
//     public static void main (String[] args) {
//         int c=3, r=3;
//         int a[][]={{2,5,6},{8,4,12},{6,7,3}};
//         boolean saddle=false;
//         int max=0, i, j,k=0, min=0;
//         for(int d=0;d<c;d++ ){
//             i=d;
//             j=0;
//             min=a[i][j];
//             while(j<r){
//                 if(a[i][j]<min){
//                     min=a[i][j];
//                     k=j;
//                 }
//                 j++;
//             }
//             i=0;
//             while(i<c){
//                 if(min>=a[i][k]){
//                     saddle=true;
//                 }
//                 else{
//                     saddle=false;
//                     break;-
//                 }
//                 i++;
//             }
//             if(saddle){
//                 System.out.println(min);
//                 break;
//             }
            
//         }
//         if(!saddle)
//         System.out.println("no");
//     }
// }


                    //. Matrix ADD

// public class Main{
//     public static void main (String[] args) {
//         int r1=3, r2=3, c1=3, c2=3;
//         int[][] a={{1,1,1},{1,1,1},{1,1,1}};
//         int[][] b={{1,1,1},{1,1,1},{1,1,1}};
//         int[][] c=new int[r1][c1];
//         if(r1==r2 && c1==c2){
//             for(int i=0; i<r1; i++){
//                 for(int j=0; j<c1; j++){
//                     c[i][j]=a[i][j]+b[i][j];
//                 }
//             }
            
//         }
//         for(int i[] : c){
//             for(int j : i){
//                 System.out.print(j+" ");
//             }
//             System.out.println();
//         }
//     }
// }


                                // MATRIC MUL
                                
                                
// public class Main{
//     public static void main (String[] args) {
//         int r1=2, r2=2, c1=2, c2=2;
//         int[][] a={{1,0},{2,1}};
//         int[][] b={{3,0},{0,1}};
//         int[][] c=new int[r1][c1];
//         if(c1==r2){
//             for(int i=0; i<r2; i++){
//                 for(int j=0; j<c1; j++){
//                   c[i][j]=0;
//                   for(int k=0; k<r1;k++){
//                       c[i][j] += a[i][k]*b[k][j];
//                   }
//                 }
//             }
            
//         }
//         for(int i[] : c){
//             for(int j : i){
//                 System.out.print(j+" ");
//             }
//             System.out.println();
//         }
//     }
// }



                        // EXPRESSION (NOT WORKING)
                        
                        
// public class Main{
//     public static void main (String[] args) {
//         String s="a-(b+c)";
//         StringBuilder str = new StringBuilder();
//         for(int i=0; i<s.length(); i++){
//             if(s.charAt(i)=='(' || s.charAt(i)==')'){
//                 if(i==0){
//                     i++;
//                 }
//                 else{
//                     if(s.charAt(--i)=='+'){
//                         i++;
//                     }
//                     else{
//                         for(int k=i; k<s.length(); k++){
//                             if(s.charAt(k)=='+'){
//                                 str.append('-');
//                             }
//                             else if(s.charAt(k)==')'){
//                                 break;
//                             }
//                             else if(s.charAt(k)=='-'){
//                                 str.append('+');   
//                             }
//                             else{
//                                 str.append(s.charAt(k));
//                             }
//                         }
//                     }
//                 }
                
//             }
//             else{
//                 str.append(s.charAt(i));
//             }
//         }
//         System.out.println(str);
//     }
// }


// import java.util.*;
// class Main {
//     static String simplify(String str)
//     {
//         int len = str.length();
//         char res[] = new char[len];
//         int index = 0, i = 0;
//         Stack<Integer> s = new Stack<Integer> ();
//         s.push(0);
//         while (i < len) {
//             if(str.charAt(i) == '(' && i == 0) {
//                 i++;
//                 continue;
//             }
//             if (str.charAt(i) == '+') {
//                 if (s.peek() == 1)
//                     res[index++] = '-';
//                 if (s.peek() == 0)
//                     res[index++] = '+';
//             }
//             else if (str.charAt(i) == '-') {
//                 if (s.peek() == 1)
//                     res[index++] = '+';
//                 else if (s.peek() == 0)
//                     res[index++] = '-';
//             }
//             else if (str.charAt(i) == '(' && i > 0) {
//                 if (str.charAt(i - 1) == '-') {
//                     int x = (s.peek() == 1) ? 0 : 1;
//                     s.push(x);
//                 }
//                 else if (str.charAt(i - 1) == '+')
//                     s.push(s.peek());
//             }
//             else if (str.charAt(i) == ')')
//                 s.pop();
//             else
//                 res[index++] = str.charAt(i);
//             i++;
//             }
//         return new String(res);
//     }
//     public static void main(String[] args)
//     {
//         String s1 = "(a-(b+c))";
//         // String s2 = "a-(b-c-(d+e))-f";
//         System.out.println(simplify(s1));
//         // System.out.println(simplify(s2));
//     }
// }


public class Main{
    public static void main (String[] args) {
        String sb="a-(b+c)+(d-c)";
        StringBuilder s=new StringBuilder(sb);
        for(int i=0; i<s.length(); i++){
            if(s.charAt(i)=='('){
                if(s.charAt(--i)=='-'){
                    while(s.charAt(i)!=')'){
                        if(s.charAt(i)=='+')
                            s.charAt(i)='-';
                        else if(s.charAt(i)=='-')
                            s.charAt(i)='+';
                        i++;
                    }
                }
            }
        }
        System.out.println(s);
    }
}



                        // MATRIX 90 DEGREE ROTATE

// public class Main{
//     public static void main (String[] args) {
//         int r=3, c=3;
//         int[][] a={{1,2,3},{4,5,6},{7,8,9}};
//         if(r==c){
//             for(int i=0; i<r; i++){
//                 for(int j=i+1; j<c; j++){
//                     int temp=a[i][j];
//                     a[i][j]=a[j][i];
//                     a[j][i]=temp;
//                     //System.out.print(a[i][j]+" ");
//                 }
//                 //System.out.println();
//             }
//         }
//         int n=r-1;
//         for(int i=0; i<r; i++){
//             for(int j=0; j<n/2; j++){
//                 int temp =a[i][j];
//                 //System.out.println(temp);
//                 a[i][j]=a[i][n-j];
//                 //System.out.println(a[i][j]);
//                 a[i][n-j]=temp;
//                 //System.out.println(a[i][n-j]);
//                 //System.out.print(a[i][j]+" ");
//             }
//             //System.out.println();
//         }
//         for (int i=0; i<r; i++) {
//                 for (int j=0; j<c; j++) {
//                     System.out.print(a[i][j]+" ");
//                 }
//                 System.out.println();
//             }
//     }
// }


                            // SHIFT ROWS
// public class Main{
//     public static void main (String[] args) {
//         int r=3, c=3, n=3;
//         int[][] a={{1,2,3},{4,5,6},{7,8,9}};
//         int[][] b=new int[r][c];
//         int k=4;
//         if(k>r){
//             System.out.println("wrong");
//         }
//         else{
//             for(int i=0; i<r; i++){
//                 for(int j=0; j<c; j++){
//                     b[i][j]=a[i][(j+c-k)%r];
//                     System.out.print(b[i][j]+" ");
                        
//                 }
//                 System.out.println();
//             }
//         }
//     }
// }


                            // SPIRAL MATRIX

// import java.io.*;
// class Main {

//     public static void main(String[] args) {
//         int R = 4;
//         int C = 4;
//         int a[][] = { { 1, 2, 3, 4 },
//                       { 5, 6, 7, 8 },
//                       { 9, 10, 11, 12 },
//                       { 13, 14, 15, 16 } };

//         int i, k = 0, l = 0;

//         while (k < R && l < C) {
//             for (i = l; i < C; ++i) {
//                 System.out.print(a[k][i] + " ");
//             }
//             k++;

//             for (i = k; i < R; ++i) {
//                 System.out.print(a[i][C - 1] + " ");
//             }
//             C--;

//             if (k < R) {
//                 for (i = C - 1; i >= l; --i) {
//                     System.out.print(a[R - 1][i] + " ");
//                 }
//                 R--;
//             }

//             if (l < C) {
//                 for (i = R - 1; i >= k; --i) {
//                     System.out.print(a[i][l] + " ");
//                 }
//                 l++;
//             }
//         }
//     }
// }

                        

// public class Main{
//     public static void main (String[] args) {
//         int[][] a={{1,2,3,4},
//                   {5,6,7,8},
//                   {9,1,2,3}};
//         int sr=0, sc=0, er=2, ec=3;
        
//         while( sr<=er && sc<=ec)
//         {
//             for(int i=sc; i<=ec; i++)
//                 System.out.print(a[sr][i]+" ");
//             sr++;
//             for(int i=sr; i<=er; i++)
//                 System.out.print(a[i][ec]+" ");
//             ec--;
//             if( sr<=er && sc<=ec){
//                 for(int i=ec; i>=sc; i--)
//                     System.out.print(a[er][i]+" ");
//                 er--;
//                 for(int i=er; i>=sr; i--)
//                     System.out.print(a[i][sc]+" ");
//                 sc++;
//             }
//         }
//     }               
// }





















