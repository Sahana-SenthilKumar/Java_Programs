import java.lang.Math;
import java.util.Scanner;
public class Main
{
        
        //Method   
    
    
//     static int a=10,b=20;
//     static void add(){
//         System.out.println(a+b);
//     }
// 	public static void main(String[] args) {
// 	    add();
// 	    System.out.println(a+b);
// 		System.out.println("Hello World");
// 	}

        //Static block
    
//     static{
//         System.out.println("Hello");
//     }
// 	public static void main(String[] args) {
// 		System.out.println("Hello World");
// 	}

    //     static int a=20;
    //     static{
    //         System.out.println(a);
    //     }
    //     public static void main(String[] args) {
    //         System.out.println(a);
		  //  System.out.println("Hello World");
		  
		 //Instance block
		 
		 
    //     static int a=20;
    //     static{
    //         System.out.println(a);
    //     }
    //     {
    //         System.out.println("Instance");
    //     }
    //     public static void main(String[] args) {
    //         Main at=new Main();
		  //  System.out.println("Hello World");
		  //  Main t=new Main();
		    
		    
		    //Constructor
		    
// 		Main()
//         {
//             System.out.println("Constructor");
//         }
//         public static void main(String[] args) {
//             Main at=new Main();
// 		    System.out.println("Hello World");
// 		    Main t=new Main();

//     Main()
//     {
//         System.out.println("Constructor");
//     }
//     {
//         System.out.println("Instance");
//     }
//     public static void main(String[] args) {
//         Main at=new Main();
// 		System.out.println("Hello World");
// 	}


//     Main()
//     {
//         System.out.println("Constructor");
//     }
//     {
//         System.out.println("Instance");
//     }
//     static{
//         System.out.println("Static");
//     }
//     public static void main(String[] args) {
//         Main at=new Main();
// 		System.out.println("Hello World");
// 	}

    // Main()
    // {
    //     System.out.println("Constructor");
    // }
    // Main(int a){
    //     System.out.println("int a");
    // }
    // Main(float f ){
    //     System.out.println("Float");
    // }
    // Main(int a, int b){
    //     System.out.println("int a,b ");
    // }
    //     public static void main(String[] args) {
    //         Main at=new Main(10);
    //         Main att=new Main(10,20);
		  //  System.out.println("Hello World");
		  //  Main yy=new Main(90.8f);
		  //  Main t=new Main();
	
// 	int a,b;	  
//     Main(int x)
//     {
//         a=b=x;
//     }
//      Main(int x, int y)
//     {
//         a=x;
//         b=y;
//     }
//     void sum(){
//         System.out.println(a+b);
//     }
//     public static void main(String[] args) {
//         Main n=new Main(10);
//         Main m=new Main(10,20);
// 		System.out.println("Hello World");
// 		m.sum();
// 		n.sum();


        //'this' keyword

// 	int a,b;	  
//      Main(int x, int y)
//     {
//         this.a=x;
//         this.b=y;
//     }
//     void sum(){
//         System.out.println(a+b);
//     }
//     public static void main(String[] args) {
//         Main n=new Main(10,40);
//         Main m=new Main(10,20);
// 		System.out.println("Hello World");
// 		m.sum();
// 		n.sum();

    //Greatest of two numbers
    
//     int a,b;	  
//     Main(int a, int b)
//     {
//         this.a=a;
//         this.b=b;
//         if(a>b)
//             System.out.println(a+" is largest");
//         else
//             System.out.println(b+" is largest");
//     }
//     public static void main(String[] args) {
//         Main n=new Main(10,40);
//         Main m=new Main(10,20);
// 		System.out.println("Hello World");
		
// 	int a,b;	  
//     Main(int a, int b)
//     {
//         this.a=a;
//         this.b=b;
        
//     }
//     void large(){
//         if(a>b)
//             System.out.println(a+" is largest");
//         else
//             System.out.println(b+" is largest");
//     }
//     public static void main(String[] args) {
//         Main n=new Main(10,40);
//         Main m=new Main(10,20);
// 		System.out.println("Hello World");
// 		n.large();
// 		m.large();

    //Greatest of 3 numbers
    
//     int a,b,c;	  
//     Main(int x, int y, int z)
//     {
//         a=x;
//         b=y;
//         c=z;
        
//     }
//     void large(){
//         if(a>b && a>c)
//             System.out.println(a+" is largest");
//         else if(b>a && b>c)
//             System.out.println(b+" is largest");
//         else
//             System.out.println(c+" is largest");
//     }
//     public static void main(String[] args) {
//         Main n=new Main(10,40,50);
//         Main m=new Main(10,20,2);
// 		System.out.println("Hello World");
// 		n.large();
// 		m.large(); 


        //Perfect Number
        
//     Main(int a){
//       int n=factsum(a);
//       if(n==a)
//         System.out.println(a+" is a Perfect Number");
//       else
//         System.out.println(a+" is not a Perfect Number");
            
//     }
    
//     int factsum(int a){
//         int sum=0;
//         for(int i=1;i<=a/2;i++){
//             if(a%i==0){
//                 sum=sum+i;
//             }
//         }
//         return sum;
//     }
// 	public static void main(String[] args){
// 	    Scanner sc=new Scanner(System.in);
// 	    System.out.println("Enter a Number :");
// 	    int x=sc.nextInt();
// 	    Main m=new Main(x);

        
        //Sunny Number
        
//     boolean sunny(int a){
//         int y=a+1;
//         for(int i=1;i<=y/2;i++){
//             int z=i*i;
//             if(z==y)
//                 return true;
//             if(z>y)
//                 break;
//         }
//         return false;
//     }
// 	public static void main(String[] args){
// 	    Scanner sc=new Scanner(System.in);
// 	    System.out.println("Enter a Number :");
// 	    int x=sc.nextInt();
// 	    Main m=new Main();
// 	    boolean b=m.sunny(x);
// 	    if(b)
// 	        System.out.println(x+" is a Sunny Number");
// 	    else
// 	        System.out.println(x+" is not a Sunny Number");
	    
// 	}


        //Spy number
        
//         int a;
//         Main(int y){
//             this.a=y;
            
//         }
//         void spy()
//         {
//         int sum=0, prod=1, rem, num=a;
//         while(a!=0){
//             rem=a%10;
//             sum=sum+rem;
//             prod=prod*rem;
//             a=a/10;
//         }
//         if(sum==prod)
//             System.out.println(num+" is a Spy Number");
//         else
//             System.out.println(num+" is not a Spy Number");
//     }
// 	public static void main(String[] args)
// 	{
// 	    Scanner sc=new Scanner(System.in);
// 	    System.out.println("Enter a Number :");
// 	    int x=sc.nextInt();
// 	    Main m=new Main(x);
// 	    m.spy();
	    
// 	}

        //Automorphic Number

	public static void main(String[] args)
	{
	    Scanner sc=new Scanner(System.in);
	    System.out.println("Enter a Number :");
	    int a=sc.nextInt();
	    int sq=a*a, num=a;
        while(a>0){
            if(a%10 == sq%10){
                a/=a;
                sq/=sq;
            }
            else
                break;
        }
        if(a==0)
            System.out.println(num+" is an Automorphic Number");
        else
            System.out.println(num+" is not an Automorphic Number");
	    
	}

}

