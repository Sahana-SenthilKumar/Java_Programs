import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		
		
/*      
        21 //Sort an Array
        
		int[] a={3,5,61,7,8,23,45,0};
		for (int i=0;i<a.length-1;i++){
		    for(int j=i+1;j<a.length;j++){
		        if(a[i]>a[j]){
		            int temp=a[i];
		            a[i]=a[j];
		            a[j]=temp;
		        }
		    }
		}
		System.out.println("Sorted Array : ");
	    for(int i:a)
	        System.out.print(i+" ");
	   
	        
	   22 //Given element in the array
		
 
        int[] a={1,2,3,4,5,6,7};
        System.out.println("Enter the element to search");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        boolean q=false;
        for (int i=0;i<a.length-1;i++){
            if(a[i]==n){
                q=true;
                break;
            }
        }
        if(q){
            System.out.println("The element is present in the array.");
        }
        else{
            System.out.println("The element is not present in the array.");
        
        }
        
        
        23. //Insert an element in a sorted array in correct position
        
        int[] a=new int[20];
        int i,j,e,n;
        System.out.println("Enter the number of elements :");
        Scanner sc=new Scanner(System.in);
        n=sc.nextInt();
        System.out.println("Enter the elements of array :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        System.out.println("Enter the element to be inserted in the array :");
        e=sc.nextInt();
        for(i=0;i<n;i++){
            if(a[i]>e)
                break;
        }
        System.out.println("Index : "+i);
        for(j=n;j>i;j--){
            a[j]=a[j-1];
        }
        a[i]=e;
        n++;
        for(i=0;i<n;i++)
        System.out.print(a[i]+" ");
        
        
        24. //Insert an element in a given index
        
        int[] a=new int[20];
        int index,i,j,e,n;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements :");
        n=sc.nextInt();
        System.out.println("Enter the array elements :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        System.out.println("Enter the element to insert :");
        e=sc.nextInt();
        System.out.println("Enter the index to be inserted :");
        index=sc.nextInt();
        for(j=n;j>index;j--)
            a[j]=a[j-1];
        a[j]=e;
        n++;
        for(i=0;i<n;i++)
            System.out.print(a[i]+" ");
         
            
        25. //Insert an element in a given position
 
        int[] a=new int[20];
        int pos,i,j,e,n;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements :");
        n=sc.nextInt();
        System.out.println("Enter the array elements :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        System.out.println("Enter the element to insert :");
        e=sc.nextInt();
        System.out.println("Enter the position to be inserted :");
        pos=sc.nextInt();
        for(j=n;j>=pos;j--)
            a[j]=a[j-1];
        a[j]=e;
        n++;
        for(i=0;i<n;i++)
            System.out.print(a[i]+" ");
         
            
        26. //Insert an element next to the given element
 
        int[] a=new int[20];
        int ge,i,j,e,n;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements :");
        n=sc.nextInt();
        System.out.println("Enter the array elements :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        System.out.println("Enter the element to insert :");
        e=sc.nextInt();
        System.out.println("Enter the elemrnt to which to be inserted next :");
        ge=sc.nextInt();
        for(i=0;i<n;i++){
            if(ge==a[i])
                break;
        }
        System.out.println("Given element index : "+i);
        for(j=n;j>i+1;j--)
            a[j]=a[j-1];
        a[j]=e;
        n++;
        for(i=0;i<n;i++)
            System.out.print(a[i]+" ");
        
            
        27 // Remove the middle element
            
        int[] a=new int[20];
        int mid,n,i,j;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements :");
        n=sc.nextInt();
        System.out.println("Enter the array elements :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        for(i=0;i<n/2;i++)
            mid=a[i];
        System.out.println("Middle element "+a[i]+" its index : "+i);
        for(j=i;j<=n;j++)
            a[j]=a[j+1];
        n--;
        System.out.println("Array after removing the middle element");
        for(i=0;i<n;i++)
            System.out.print(a[i]+" ");
        
            
        28. //Remove the element next to the given element
        
        int[] a=new int[20];
        int ge,i,j,n;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements :");
        n=sc.nextInt();
        System.out.println("Enter the array elements :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        System.out.println("Enter the element to which the element be removed :");
        ge=sc.nextInt();
        for(i=0;i<n;i++)
            if(ge==a[i])
        for(j=i+1;j<n;j++)
            a[j]=a[j+1];
        n--;
        System.out.println("Array after removing the element");
        for(i=0;i<n;i++)
            System.out.print(a[i]+" ");
        
            
        29. //Remove the element in the give index

        int[] a=new int[20];
        int index,i,j,n;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements :");
        n=sc.nextInt();
        System.out.println("Enter the array elements :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        System.out.println("Enter the index of the element to be removed :");
        index=sc.nextInt();
        for(i=0;i<n;i++)
            if(index==i)
            break;
        for(j=i;j<n;j++)
            a[j]=a[j+1];
        n--;
        System.out.println("Array after removing the element");
        for(i=0;i<n;i++)
            System.out.print(a[i]+" ");
        
            
        30. //Remove the element in the give position

        int[] a=new int[20];
        int pos,i,j,n;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements :");
        n=sc.nextInt();
        System.out.println("Enter the array elements :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        System.out.println("Enter the position of the element to be removed :");
        pos=sc.nextInt();
        for(i=0;i<n;i++)
            if(pos==i)
            break;
        for(j=i-1;j<n;j++)
            a[j]=a[j+1];
        n--;
        System.out.println("Array after removing the element");
        for(i=0;i<n;i++)
            System.out.print(a[i]+" ");
         
            
        31. //Find the missing element in the Array
        
        int[] a={10,20,30,40,60,70,80,90};
        int i, d=a[1]-a[0];
        for(i=1;i<a.length;i++)
            if(a[i]!=a[i-1]+d)
                System.out.println("The missing element is : "+(a[i-1]+d));
        
        
        32. //Count number of zeros and ones in the binary array
    
        int[] a=new int[20];
        int count1=0,count0=0,i,j,n;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements :");
        n=sc.nextInt();
        System.out.println("Enter the binary array elements :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        for(i=0;i<n;i++){
            if(a[i]==1)
                count1++;
            else
                count0++;
        }
        System.out.println("The number of 1's in array : "+count1);
        System.out.println("The number of 0's in array : "+count0);
        
        
        33. //Merge two sorted array
        
        int[] a={1,3,5,7,9};
        int[] b={2,4,6,8,10};
        int[] c=new int[a.length+b.length];
        for(int i=0;i<a.length;i++){
            c[i]=a[i];
        }
        for(int i=0;i<b.length;i++){
            c[i+a.length]=b[i];
        }
        System.out.println("Merged array :");
        for(int i : c)
        System.out.print(i+" ");
        for(int i=0;i<c.length;i++)
            for(int j=i+1;j<c.length;j++)
            if(c[i]>c[j]){
                int temp=c[i];
                c[i]=c[j];
                c[j]=temp;
            }
        System.out.println();
        System.out.println("Sorted merged array :");
        for(int i : c)
        System.out.print(i+" ");
        
        
        34. //Kth largest elements
        
        int[] a=new int[20];
        int i,j,n,temp,k;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of elements :");
        n=sc.nextInt();
        System.out.println("Enter the array elements :");
        for(i=0;i<n;i++)
            a[i]=sc.nextInt();
        for(i=0;i<n;i++)
            for(j=i+1;j<n;j++)
            if(a[i]<a[j])
            {
                temp=a[i];
                a[i]=a[j];
                a[j]=temp;
            }
        System.out.println("Sorted array :");
        for(i=0;i<n;i++)
            System.out.print(a[i]+" ");
        System.out.println();
        System.out.println("Enter the kth largest element to find");
        k=sc.nextInt();
        System.out.println("The "+k+" largest element is : "+a[k-1]);
        
        
        35. //Reverse an array

        int[] a={10,20,30,40,50};
        int  temp;
        for(int i=0;i<a.length/2;i++){
            temp=a[i];
            a[i]=a[a.length-1-i];
            a[a.length-1-i]=temp;
        }
        System.out.println("Reversed array :");
        for(int k : a)
            System.out.print(k+" ");
            
*/


	}
}
