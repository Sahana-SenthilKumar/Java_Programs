import java.util.Scanner;
public class Main
{
	
/*
                                           
                                            //RECURSION
                                            
                                            
                                            
    1. //Fibonacci
    
        public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        int n1=0,n2=1,n3;
        System.out.println("Fibonacci Series upto "+n+" terms :");
        for(int i=1; i<=n;i++){
            System.out.print(n1+" ");
            n3=n1+n2;
            n1=n2;
            n2=n3;
        }
        
    2.a. //Fibonacci using Recursive Function
        
    int a=0,b=1;
    int fib(int x){
        int c=0;
        if(x>0){
            c=a+b;
            a=b;
            b=c;
            System.out.print(c+" ");
            fib(x-1);
        }
        return 1;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        System.out.println("Fibonacci Series upto "+n+" terms :");
        int a=0,b=1;
        System.out.print(a+" "+b+" ");
        Main m=new Main();
        m.fib(n-2);
     
    
    2.b. //Fibonacci using Recursive Function  
       
    static int a=0,b=1,c;
    static void fib(int x){
        if(x>0){
            System.out.print(a+" ");
            c=a+b;
            a=b;
            b=c;
            fib(x-1);
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Main m=new Main();
        System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        System.out.println("Fibonacci Series upto "+n+" terms :");
        m.fib(n);
        
        
    3.a. // Recursive Function
    
    void fun(int n)
    {
        if(n>0)
        {
            System.out.println(n);
            fun(n-1);
        }
    }
    public static void main(String[] args)
        {
            Main m=new Main();
            m.fun(10);
        }
    
    
    3.b. // Recursive Function
    
    void fun(int n)
    {
        if(n>0)
        {
            fun(n-1);
            System.out.println(n);
            
        }
    }
    public static void main(String[] args)
        {
            Main m=new Main();
            m.fun(10);
        }
    
    
    
                                        
                                            //INHERITANCE
                                       
                                       
                                        
    3. //Single Inheritance

    class Parent
    {
        void display()
        {
            System.out.println("Parent Method");
        }
    }
    public class Main extends Parent{
        public static void main(String[] args){
            Main c=new Main();
            c.display();
        }
    }
    
    
    4. //Multi-Level Inheritance

    class Grand
    {
        void  hello()
        {
            System.out.println("Grand Parent Method");
        }
    }
    class Parent extends Grand
    {
        void display()
        {
            System.out.println("Parent Method");
        }
    }
    public class Main extends Parent{
        public static void main(String[] args){
            Main c=new Main();
            Parent p=new Parent();
            c.hello();
            c.display();
            p.hello();
            p.display();
        }
    }
    
    
    5. //Heirarchy Inheritance
    
    class Grand
    {
        void  hello()
        {
            System.out.println("Grand Parent Method");
        }
    }
    class Parent extends Grand
    {
        void display()
        {
            System.out.println("Parent Method");
        }
    }
    public class Main extends Grand{
        public static void main(String[] args){
            Main c=new Main();
            Parent p=new Parent();
            c.hello();
            p.hello();
            p.display();
        }
    }
    
    
    6. //Hybrid Inheritance
    
    class Grand
    {
        void  hello()
        {
            System.out.println("Grand Parent Method");
        }
    }
    class Hello extends Grand
    {
        void happy(){
            System.out.println("Happy");
        }
    }
    class Parent extends Hello
    {
        void display()
        {
            System.out.println("Parent Method");;
        }
    }
    public class Main extends Parent{
        public static void main(String[] args){
            Main c=new Main();
            Hello h=new Hello();
            Parent p=new Parent();
            c.hello();
            c.happy();
            c.display();
            p.happy();
        }
    }
    
    

                                // OVER-RIDING => RUNTIME POLYMORPHISM  
                            
                            
    7. //Over-riding
    
    class Cat
    {
        void eat()
        {
            System.out.println("Milk");
        }           
    }
    public class Main extends Cat{
        void eat1
        {
            System.out.println("Meat");    
        }
        void eat()
        {
            System.out.println("Meat");
        }
        public static void main(String[] args){
            // Cat c=new Cat();
            // c.eat();             // O/P: Milk
            // Main t=new Main();
            // t.eat();             // O/P: Meat
            
            // Cat c=new Main();    // O/P: Meat
            // c.eat();
            
            // Cat c=new Main();    //  Error
            // c.eat1();
            
            // Main m=new Cat();    //  Error
            // m.eat();   
        }
    }



                                        // ABSTRACTION
         
         
         
                                        
    8.a. //ABSTRACTION
    
    abstract class Employee
    {
        void job()
        {
            System.out.println("Job Description");
        }
        abstract void account();
    }
    class Manager extends Employee
    {
        void account()
        {
            System.out.println("Account Details");
        }
    }
    public class Main{
        public static void main(String[] args){
            Manager m=new Manager();
            m.job();
            m.account();
        }
    }
    
    
    8.b. //ABSTRACTION

    abstract class Employee
    {
        void job()
        {
            System.out.println("Job Description");
        }
        abstract void account();
    }
    abstract class Manager extends Employee
    {
        void display()
        {
            System.out.println("Display");
        }
    }
    class staff extends Manager
    {
        void account()
        {
            System.out.println("Account Details");
        }
    }
    class people
    {
        void person()
        {
            System.out.println("Person");
        }
    }
    
    public class Main{
        public static void main(String[] args){
            staff m=new staff();
            m.job();
            m.account();
            m.display();
            
            people p=new people();
            p.person();
            
            //Employee e=new Employee(); // Error : Employee is abstract so cannot be initialized
            //Manager n=new Manager();   // Error : Manager is abstract so cannot be initialized
        }
    }
        




                                        // AGGREGATION
                                        
                                        
                                        
    9. //Aggregation
    
    class Student
    {
        int roll;
        int age;
        Address add;
    }
    class Address
    {
        int door;
        String street;
        String dist;
    }
    public class Main{
        public static void main(String[] args){
            Student s=new Student();
            s.roll=85;
            s.age=19;
            
            Address a=new Address();
            a.door=8;
            a.street="Street";
            a.dist="CBE";
            
            s.add=a;
            System.out.println(s.add.dist);
        }
    }

*/



