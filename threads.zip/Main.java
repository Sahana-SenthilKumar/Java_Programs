                                            // THREADS
                     
                                            
    // 1. // Thread Class 
    
    
// class MyThread extends Thread{
//     public void run(){
//         for(int i=0;i<=100;i++)
//             System.out.println("Child Thread");
//     }
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 	    MyThread t=new MyThread();
// 	    t.start();
// 	    for(int i=0;i<=100;i++)
//             System.out.println("Main Thread");
		
// 	}
// }


    // 2. // Runnable Interface
    
    
// class MyThread implements Runnable{
//     public void run(){
//         for(int i=0;i<=10;i++)
//             System.out.println("Child Thread");
//     }
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 	    MyThread r=new MyThread();
// 	    Thread t=new Thread(r);
// 	    t.start();
// 	    for(int i=0;i<=10;i++)
//             System.out.println("Main Thread");
		
// 	}
// }


    // 3. // set and get Name()
    
    
// class MyThread extends Thread{
//     public void run(){
//         for(int i=0;i<=100;i++)
//             System.out.println("Child Thread");
//     }
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 	    MyThread t=new MyThread();
// 	    MyThread t1=new MyThread();
// 	    System.out.println(Thread.currentThread().getName());
// 	    System.out.println(t.getName());
// 	    System.out.println(t1.getName());
// 	    //Thread.currentThread().setName("Hello");
// 	    System.out.println(Thread.currentThread().getName());
// 	    System.out.println(30/0);
	    
		
// 	}
// }


    // 4. // set and get Priority()
    
    
// class MyThread extends Thread{
//     public void run(){
//         for(int i=0;i<=100;i++)
//             System.out.println("Child Thread");
//     }
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 	    MyThread t=new MyThread();
// 	    MyThread t1=new MyThread();
// 	    System.out.println(Thread.currentThread().getPriority());
// 	    System.out.println(t.getPriority());
// 	    System.out.println(t1.getPriority());
// 	    Thread.currentThread().setPriority(8);
// 	    System.out.println(Thread.currentThread().getPriority());
// 	    Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
// 	    System.out.println(Thread.currentThread().getPriority());
	    
		
// 	}
// }


    // 5. // yield() Method
    
    
// class MyThread extends Thread{
//     public void run(){
//         for(int i=0;i<=1000;i++)
//             System.out.println("Child Thread");
//     }
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 	    MyThread t=new MyThread();
// 	    t.start();
// 	    Thread.yield();
// 	    for(int i=0;i<=1000;i++)
//             System.out.println("Main Thread");
	    
		
// 	}
// }


    // 6. // join() Method
    
    
// class MyThread extends Thread{
//     public void run(){
//         for(int i=0;i<=100;i++)
//             System.out.println("Child Thread");
//     }
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 	    MyThread t=new MyThread();
// 	    t.start();
// 	    try{
// 	        //t.join();
// 	        //t.join(2000);
// 	        t.join(0,2);
// 	    }
// 	    catch(Exception e){
	        
// 	    }
// 	    for(int i=0;i<=100;i++)
//             System.out.println("Main Thread");
	    
		
// 	}
// }


    // 7. // sleep() Method
    
    
// class MyThread extends Thread{
//     public void run(){
//         for(int i=0;i<=10;i++)
//             System.out.println("Child Thread");
//     }
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 	    MyThread t=new MyThread();
// 	    t.start();
// 	    for(int i=0;i<=10;i++){
// 	        try{
// 	            //Thread.sleep(1000);
// 	            Thread.sleep(1000,5);
// 	        }
// 	        catch(Exception e){
	        
// 	        }
//             System.out.println("Main Thread");
	    
// 	    }
		
// 	}
// }


    // 8. // interrupt() Method
    
    
// class MyThread extends Thread{
//     public void run(){
//         for(int i=0;i<=100;i++){
//             try{
// 	            Thread.sleep(500);
// 	            //Thread.sleep(1000,5);
// 	        }
// 	        catch(Exception e){
	        
// 	        }
//             System.out.println("Child Thread");
//             System.out.println();
//         }
//     }
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 	    MyThread t=new MyThread();
// 	    t.start();
// 	    t.interrupt();
// 	    for(int i=0;i<=100;i++){
// 	        try{
// 	            Thread.sleep(500);
// 	            //Thread.sleep(1000,5);
// 	        }
// 	        catch(Exception e){
	        
// 	        }
//             System.out.println("Main Thread");
	    
// 	    }
		
// 	}
// }


    // 9. // Synchronized Method
    
// class display{
//     public synchronized void show(String name){
//         for(int i=0;i<=100;i++){
//             System.out.print("Hello ");
//             System.out.println(name);
//         }
//     }
// }    
// class MyThread extends Thread{
//     display d;
//     String name;
//     MyThread(display d, String name){
//         this.d=d;
//         this.name=name;
//     }
//     public void run(){
//         d.show(name);
//     }
        
// } 
// public class Main
// {
// 	public static void main(String[] args) {
// 	    display d=new display();
// 	    MyThread s1=new MyThread(d,"ABC");
// 	    MyThread s2=new MyThread(d,"XYZ");
// 	    s1.start();
// 	    s2.start();
		
// 	}
// }


    // 10. // Synchronized Block
    
class display{
    public void show(String name){
        synchronized(this){
            for(int i=0;i<=100;i++){
                System.out.print("Hello ");
                System.out.println(name);
            }
        }   
    }
}    
class MyThread extends Thread{
    display d;
    String name;
    MyThread(display d, String name){
        this.d=d;
        this.name=name;
    }
    public void run(){
        d.show(name);
    }
        
} 
public class Main
{
	public static void main(String[] args) {
	    display d=new display();
	    MyThread s1=new MyThread(d,"ABC");
	    MyThread s2=new MyThread(d,"XYZ");
	    s1.start();
	    s2.start();
		
	}
}                           

