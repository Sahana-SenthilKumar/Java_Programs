/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
// 		int[] a=new int[20];
// 		Scanner sc=new Scanner(System.in);
// 		System.out.println("Enter the number of terms :");
// 		int n=sc.nextInt();
// 		System.out.println("Enter the array elements :");
// 		for(int k=1;k<=n;k++){
// 		    a[k]=sc.nextInt();
// 		}
        int[] a={10,20,10,40,10};
		int i,j,index=0, m=0, n=a.length;
// 		System.out.print("Duplicate elements in the array : ");
		for(i=0;i<n;i++){
		    for(j=i+1;j<n;j++){
		        if(a[i]==a[j]){
		            index=j;
		          //  System.out.println(j+);
		        }
		    }
		}
		System.out.println();
		for(int s=index;s<n-1;s++){
		    a[s]=a[s+1];
		}
		n--;
		for(int s=0;s<n;s++){
		    System.out.print(a[s]+" ");
		}
	}
}
