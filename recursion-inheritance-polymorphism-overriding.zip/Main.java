import java.util.Scanner;
// public class Main
// {
	
/*
                                            //RECURSION
                                            
    1. //Fibonacci
    
        public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        int n1=0,n2=1,n3;
        System.out.println("Fibonacci Series upto "+n+" terms :");
        for(int i=1; i<=n;i++){
            System.out.print(n1+" ");
            n3=n1+n2;
            n1=n2;
            n2=n3;
        }
        
    2.a. //Fibonacci using Recursive Function
        
    int a=0,b=1;
    int fib(int x){
        int c=0;
        if(x>0){
            c=a+b;
            a=b;
            b=c;
            System.out.print(c+" ");
            fib(x-1);
        }
        return 1;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        System.out.println("Fibonacci Series upto "+n+" terms :");
        int a=0,b=1;
        System.out.print(a+" "+b+" ");
        Main m=new Main();
        m.fib(n-2);
     
    
    2.b. //Fibonacci using Recursive Function  
       
    static int a=0,b=1,c;
    static void fib(int x){
        if(x>0){
            System.out.print(a+" ");
            c=a+b;
            a=b;
            b=c;
            fib(x-1);
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Main m=new Main();
        System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        System.out.println("Fibonacci Series upto "+n+" terms :");
        m.fib(n);
        
        
                                        //INHERITANCE
                                        
    3. //Single Inheritance

    class Parent
    {
        void display()
        {
            System.out.println("Parent Method");
        }
    }
    public class Main extends Parent{
        public static void main(String[] args){
            Main c=new Main();
            c.display();
        }
    }
    
    
    4. //Multi-Level Inheritance

    class Grand
    {
        void  hello()
        {
            System.out.println("Grand Parent Method");
        }
    }
    class Parent extends Grand
    {
        void display()
        {
            System.out.println("Parent Method");
        }
    }
    public class Main extends Parent{
        public static void main(String[] args){
            Main c=new Main();
            Parent p=new Parent();
            c.hello();
            c.display();
            p.hello();
            p.display();
        }
    }
    
    
    5. //Heirarchy Inheritance
    
    class Grand
    {
        void  hello()
        {
            System.out.println("Grand Parent Method");
        }
    }
    class Parent extends Grand
    {
        void display()
        {
            System.out.println("Parent Method");
        }
    }
    public class Main extends Grand{
        public static void main(String[] args){
            Main c=new Main();
            Parent p=new Parent();
            c.hello();
            p.hello();
            p.display();
        }
    }
    
    
    6. //Hybrid Inheritance
    
    class Grand
    {
        void  hello()
        {
            System.out.println("Grand Parent Method");
        }
    }
    class Hello extends Grand
    {
        void happy(){
            System.out.println("Happy");
        }
    }
    class Parent extends Hello
    {
        void display()
        {
            System.out.println("Parent Method");;
        }
    }
    public class Main extends Parent{
        public static void main(String[] args){
            Main c=new Main();
            Hello h=new Hello();
            Parent p=new Parent();
            c.hello();
            c.happy();
            c.display();
            p.happy();
        }
    }
*/
                            // OVER-RIDING => RUNTIME POLYMORPHISM  
    class Cat
    {
        void eat()
        {
            System.out.println("Milk");
        }
    }
    public class Main extends Cat{
        void eat()
        {
            System.out.println("Meat");
        }
        public static void main(String[] args){
            // Cat c=new Cat();
            // c.eat();
            // Main t=new Main();
            // t.eat();
            
            // Cat c=new Main();
            // c.eat();
            
            Main m=new Cat();
            m.eat();
        }
        
        
    }
 
//}
