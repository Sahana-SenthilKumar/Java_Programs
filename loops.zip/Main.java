/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
/*
        1. //Natural numbers 

		System.out.println("The first 10 natural numbers.");
		for(int i=1;i<=10;i++)
		    System.out.println(i);
		    
 
        2. //Sum of natural numbers
        
        int sum=0;
        System.out.println("The first 10 natural numbers.");
		for(int i=1;i<=10;i++){
		    System.out.print(i+" ");
		    sum=sum+i;
		}
		 System.out.println();
		 System.out.print("The Sum is : "+sum);

	

        3. //'N' Natural numbers
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number :");
        int n=sc.nextInt();
        int sum=0;
        System.out.println("The first "+n+" natural number is :");
		for(int i=1;i<=n;i++){
		    System.out.print(i+" ");
		    sum=sum+i;
		}
		 System.out.println();
		 System.out.print("The Sum of Natural Number upto "+n+" terms : "+sum);
        

        4. //Average ans sum
        
        Scanner sc=new Scanner(System.in);
        double num=0, sum=0, avg;
        System.out.println("Input the 10 numbers :");
		for(int i=1;i<=10;i++){
		    num=sc.nextInt();
		    sum=sum+num;
		}
		avg=sum/10;
	    System.out.println();
	    System.out.println("The sum of 10 number is : "+sum);
		System.out.print("The Average is : "+avg);
       


        5. //Cube
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms :");
        int num=sc.nextInt();
        System.out.println("The cube of numbers :");
        System.out.println();
        //System.out.println("Input the numbers :");
        for(int i=1;i<=num;i++){
           //int n=sc.nextInt();
		    System.out.println("Number is : "+i+" and cube of the "+i+" is : "+(i*i*i));
        }
        


        6. //Multiplication Throwable
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input the number (Table to be calculated) : ");
        int num=sc.nextInt();
        System.out.println("Multiplication Table of "+num+" is :");
        for(int i=1;i<=10;i++){
		    System.out.println(num+" x "+i+" = "+(num*i));
        }


        7. //Multiplier table vertically
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input upto the table number starting from 1 :");
        int num=sc.nextInt();
        System.out.println("Multiplication table from 1 to "+num);
        for(int i=1;i<=10;i++){
            for(int j=1;j<=num;j++){
                System.out.print(j+" x "+i+" = "+(i*j)+",  ");
            }
        }
        


        8. //Odd Natural numbers and their sum
        
        int sum=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        System.out.print("The odd numbers are : ");
		for(int i=1;i<=num ;i+=2){
		    System.out.print(i+" ");
		    sum=sum+i;
		}
		 System.out.println();
		 System.out.print("The Sum of odd Natural Number upto "+num+" terms : "+sum);
         

        9. //Pattern right angle triangle using an asterisk
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        System.out.println("Pattern right angle triangle using an asterisk");
        for(int i=1;i<=num;i++){
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
        System.out.println();
        }
        

        10. //Pattern right angle triangle using numbers
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        System.out.println("Pattern right angle triangle using numbers");
        for(int i=1;i<=num;i++){
            for(int j=1;j<=i;j++){
                System.out.print(j);
            }
        System.out.println();
        }


        11. //Pattern right angle triangle using numbers
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        System.out.println("Pattern right angle triangle using numbers");
        for(int i=1;i<=num;i++){
            for(int j=1;j<=i;j++){
                System.out.print(i);
            }
        System.out.println();
        }


        12. //Pattern right angle triangle using numbers
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        int k=1;
        System.out.println("Pattern right angle triangle using numbers");
        for(int i=1;i<=num;i++){
            for(int j=1;j<=i;j++){
                System.out.print(String.format("%3d",k++));
            }
        System.out.println();
        }
        

        13. //Pattern Pyramid using numbers
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        int k=1;
        System.out.println("Pattern Pyramid numbers");
        for(int i=1;i<=num;i++){
            for(int j=1;j<=num-i;j++)
                System.out.print(" ");
            for(int j=1;j<=i;j++){
                System.out.print(k++ +" ");
            }
        System.out.println();
        }


        14. //Pattern Pyramid using asterisk
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        int k=1;
        System.out.println("Pattern Pyramid asterisk");
        for(int i=1;i<=num;i++){
            for(int j=1;j<=num-i;j++)
                System.out.print(" ");
            for(int j=1;j<=i;j++){
                System.out.print("* ");
            }
        System.out.println();
        }
        

        15. //Factorial
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input the number : ");
        int num=sc.nextInt();
        int fact=1;
        for(int i=1;i<=num ;i++){
            fact=fact*i;
        }
        System.out.println("The Factorial of "+num+" is :"+fact);
        

        16. //Even Natural numbers and their sum
        
        int sum=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        System.out.print("The even numbers are : ");
		for(int i=2;i<=num ;i+=2){
		    System.out.print(i+" ");
		    sum=sum+i;
		}
		 System.out.println();
		 System.out.print("The Sum of even Natural Number upto "+num+" terms : "+sum);


        17. //Pattern Pyramid using numbers
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        int k=1;
        System.out.println("Pattern Pyramid numbers");
        for(int i=1;i<=num;i++){
            for(int j=1;j<=num-i;j++)
                System.out.print(" ");
            for(int j=1;j<=i;j++){
                System.out.print(i+" ");
            }
        System.out.println();
        }
        
        
        18. //Sum of Series
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input the value of x : ");
        int x=sc.nextInt();
        System.out.println("Input the number of terms : ");
        int num=sc.nextInt();
        double sum=1, term=1, deno;
        for(int i=1; i<num; i++){
            deno=(2*i)*(2*i-1);
            term=-term*x*x/deno;
            sum=sum+term;
        }
        System.out.println("The sum :"+sum);
        
        
        19. //'N' terms of a harmonic series and their sum.
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        double num=sc.nextDouble();
        double sum=0;
        for(double i=1;i<=num;i++){
            sum=sum+(1/i);
            }
        for(int i=1;i<=num;i++){
            System.out.print("1/"+i+" + ");
        }
        System.out.println();
        System.out.println("Sum of Series upto "+num+" terms : "+sum);

        
        20. //Pattern Pyramid using asterisk
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        int k=1;
        System.out.println("Pattern Pyramid asterisk");
        for(int i=1;i<=num;i++){
            for(int j=1;j<=num-i;j++)
                System.out.print(" ");
            for(int j=1;j<=(2*i-1);j++){
                System.out.print("*");
            }
        System.out.println();
        }
        
        
        21. // To display the sum of the series [ 9 + 99 + 999 + 9999 ...].
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int n=sc.nextInt();
        int k=9;
        int sum=0;
        for(int i=1;i<=n;i++){
            sum=sum+k;
            k=k*10+9;
	    }
        System.out.println("The sum of the saries = "+sum);
        
        
        22. //Floyd's Triangle
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int n=sc.nextInt();
        int k=0;
        System.out.println("Floyd's Triangle");
        for(int i=0;i<n;i++){
            if(i%2==0)
                k=0;
            else
                k=1;
            for(int j=0;j<i;j++){
                System.out.print(k);
                k=1-k;
            }
            System.out.println();
            
        }


        23. //The sum of the series [x - x^3 + x^5 + ......].
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input the value of x :");
        int x=sc.nextInt();
        System.out.println("Input number of terms : ");
        int n=sc.nextInt();
        double sum=1, num=1;
        for(int i=1;i<=n;i++){
            num=num*x/(double)i;
            sum=sum+num;
	    }
        System.out.println("The sum is : "+sum);
        

        24. //The sum of the series [x - x^3 + x^5 + ......].
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input the value of x :");
        int x=sc.nextInt();
        System.out.println("Input number of terms : ");
        int n=sc.nextInt();
        double sum=1, num=1;
        System.out.println("The values of the series : ");
        for(int i=1;i<=n;i++){
            num=num*x/(double)i;
            sum=sum+num;
            System.out.println(sum);
	    }
        System.out.println("The sum is : "+sum);
        
        
        25. //n terms of square natural numbers and their sum.

        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int n=sc.nextInt();
        int sq, sum=0;
        System.out.print("The square natural upto 5 terms are : ");
        for(int i=1;i<=n;i++){
            sq=i*i;
            System.out.print(sq+" ");
            sum=sum+sq;
        }
        System.out.println();
        System.out.println("The Sum of Square Natural Number upto 5 terms = "+sum);
        
        
        26. //The sum of the series 1 +11 + 111 + 1111 + .. n terms.

        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int n=sc.nextInt();
        int k=1;
        int sum=0;
        for(int i=1;i<=n;i++){
            sum=sum+k;
            k=k*10+1;
	    }
        System.out.println("The sum of the saries = "+sum);
        
        
        27. //Perfect Number

        Scanner sc=new Scanner(System.in);
        System.out.println("Input the number: ");
        int n=sc.nextInt();
        System.out.print("The positive divisor : ");
        int sum=0;
        for(int i=1;i<=n/2;i++){
            if(n%i==0){
                System.out.print(i+" ");
                sum=sum+i;
            }
        }
        System.out.println();
        System.out.println("The sum of the divisor is : "+sum);
        if(sum==n)
            System.out.println("So, the number is perfect.");
        else
            System.out.println("So, the number is not perfect.");
            
            
        28. //'Perfect' numbers within a given number of ranges.

        Scanner sc=new Scanner(System.in);
        System.out.println("Input the starting range or number : ");
        int start=sc.nextInt();
        System.out.println("Input the ending range of number : ");
        int end=sc.nextInt();
        int sum=0, i=1;
        System.out.print("The Perfect numbers within the given range : ");
        for(int n=start;n<=end;n++){
            while(i < n){ 
                if(n % i == 0) 
                    sum = sum + i; 

                i++; 
            }
            if(sum == n) 
                System.out.print(n+" ");
        }
        
        
        29. //Armstrong Number
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input the 3 digit number: ");
        int num=sc.nextInt();
        int rem, temp=num, sum=0;
        while(num!=0){
            rem=num%10;
            sum=sum+(rem*rem*rem);
            num=num/10;
        }
        if(temp==sum)
            System.out.println(temp+" is an Armstrong number.");
        else
            System.out.println(temp+" is not an Armstrong number.");
    
    
        31. //Diamond Pattern

        Scanner sc=new Scanner(System.in);
        System.out.println("Input number of terms : ");
        int num=sc.nextInt();
        int k=1;
        System.out.println("Pattern Pyramid asterisk");
        for(int i=1;i<=num;i++){
            for(int j=1;j<=num-i;j++)
                System.out.print(" ");
            for(int j=1;j<=(2*i-1);j++){
                System.out.print("*");
            }
        System.out.println();
        }
        for(int i=num-1;i>=0;i--){
            for(int j=1;j<=num-i;j++)
                System.out.print(" ");
            for(int j=1;j<=(2*i-1);j++){
                System.out.print("*");
            }
        System.out.println();
        }

        
        32. //Prime or not

        Scanner sc=new Scanner(System.in);
        System.out.println("Input the number: ");
        int n=sc.nextInt();
        boolean flag=true;
        for(int i=2;i<=n/2;i++){
            if(n%i==0){
                flag=false;
            }
        }
        if(flag)
            System.out.println(n+" is a prime number.");
        else    
            System.out.println(n+" is not a prime number.");
            
            
        33. //Pascal triangle
        
	   int[][] a=new int[10][10];
	   int n=5;
	   for(int i=1;i<=n;i++){
	       int k=0;
	       for(int j=1;j<=n-i;j++)
	        System.out.print(" ");
	       
	       for(int j=0;j<i;j++){
	           if(j==0||j==i){
	               a[i][j]=1;
	               System.out.print(a[i][j]+" ");
	           }
	           else{
	               a[i][j]=a[i-1][k]+a[i-1][k+1];
	               System.out.print(a[i][j]+" ");
	               k=k+1;
	           }
	       }
	       System.out.println();
	   }
	   
	   
	   34. //
	   
	   System.out.println("Enter the starting range:");
	   int start=sc.nextInt();
	   System.out.println("Enter the ending range:");
	   int end=sc.nextInt();
	   for(int l=start;l<end;l++){
	       int c=1;
	   for(int i=2;i<=l/2;i++){
	       if(l%i==0){
	           c+=1;
	       }
	   }
	   if(c==1)
	    System.out.println(l+" is Prime number");
	   }
	   
	   
	   35. //
	   
	   System.out.println("Enter the no. of terms:");
	   int n=sc.nextInt();
	   int n1=0,n2=1,n3;
	   System.out.print(n1+" "+n2+" ");
	   for(int i=1;i<=n-2;i++){
	       n3=n1+n2;
	       n1=n2;
	       n2=n3;
	       System.out.print(n3+" ");
	   }
	   
	   36. //
	   
	   int n=5;
	   for(int i=1;i<=n;i++){
	       int k=i;
	       for(int j=1;j<=n-i;j++)
	        System.out.print(" ");
	       for(int j=1;j<=2*i-1;j++){
	           if(j==1||j==2*i-1)
	            System.out.print(1);
	           else{
	               if(j<=(2*i)/2)
	                System.out.print(j);
	               else{
	                   k=k-1;
	                   System.out.print(k);
	               }
	           }
	       }
	       System.out.println();
	   }
	   
	   
	   37. //
	   
	   System.out.println("Enter the number:");
	   int n=sc.nextInt();
	   int i,r=0,rem;
	   for(i=n;i>0;i/=10){
	       rem=i%10;
	       r=r*10+rem;
	   }
	   System.out.print(r);
	   
	   
	   38. //
	   
	   System.out.println("Enter the number:");
	   int n=sc.nextInt();
	   int i,r=0,rem;
	   for(i=n;i>0;i/=10){
	       rem=i%10;
	       r=r*10+rem;
	   }
	   if(n==r)
	    System.out.println(n+" is a palindrome");
	   else
	    System.out.println(n+" is not a palindrome");
	   
	   
	   39. //
	   
	   int k=0;
	   for(int i=100;i<=200;i++){
	       if(i%9==0){
	           System.out.print(i+" ");
	           k=k+i;
	       }
	   }
	   System.out.println(k);
	   
	   40. //
	   
	   int n=5;
	   for(int i=1;i<=n;i++){
	       int k=i;
	       for(int j=1;j<=n-i;j++)
	        System.out.print(" ");
	       for(int j=1;j<=2*i-1;j++){
	           if(j==1||j==2*i-1)
	            System.out.print((char)65);
	           else{
	               if(j<=(2*i)/2)
	                System.out.print((char)(j+64));
	               else{
	                   k=k-1;
	                   System.out.print((char)(k+64));
	               }
	           }
	       }
	       System.out.println();
	   }
	   
	   
	   41. //
	   
	   System.out.println("Enter the decimal numer:");
	   int n=sc.nextInt();
	   int Binaryn=0; 
	   int count=0;
	   while(n!=0){
	       int rem=n%2;
	       double c=Math.pow(10,count);
	       Binaryn+=rem*c;
	       n/= 2;
	       count++;
	   }
	   System.out.println(Binaryn);
	   
	   42. //
	   
	   System.out.println("Enter the binary number:");
	   int b=sc.nextInt();
	   int decimal=0;
	   int n=0;
	   while(true){
	       if(b==0){
	           break;
	       }
	       else{
	           int temp=b%10;
	           decimal+=temp*Math.pow(2, n);
	           b=b/10;
	           n++;
	       }
	   } 
	   System.out.println(decimal);
	   
	   43. //
	   
	   System.out.println("Enter the two numbers:");
	   int num1=sc.nextInt();
	   int num2=sc.nextInt();
	   int hcf=0;
	   for(int i=1;i<=num1||i<=num2;i++){
	       if(num1%i==0&&num2%i==0)
	        hcf=i;
	   }
	   System.out.println("The HCF: "+ hcf);
	   
	   44. //
	   
	   System.out.println("Enter the two numbers:");
	   int num1=sc.nextInt();
	   int num2=sc.nextInt();
	   int gcd=1;
	   for(int i=1;i<=num1&&i<=num2;++i){
	       if(num1%i==0&&num2%i==0)
	        gcd = i;
	   }
	   int lcm=(num1*num2)/gcd;
	   System.out.println("The LCM is "+lcm);
	   
	   45. //
	   
	   System.out.println("Enter the two numbers:");
	   int num1=sc.nextInt();
	   int num2=sc.nextInt();
	   int lcm=(num1>num2)?num1:num2;
	   while(true){
	       if(lcm%num1==0&&lcm%num2==0){
	           System.out.println("The LCM is"+lcm);
	           break;
	       }
	       ++lcm;
	   }
	   
	   46. //
	   
	   System.out.println("Enter the binary number:");
	   int b=sc.nextInt();
	   int decimal=0;
	   int n=0;
	   while(true){
	       if(b==0){
	           break;
	       }
	       else{
	           int temp=b%10;
	           decimal+=temp*Math.pow(2, n);
	           b=b/10;
	           n++;
	       }
	   } 
	   System.out.println(decimal);
	   
	   47.
	   
	   int n,i;
	   int fact_n,lastdig;
	   System.out.print("\nEnter the number : " );
	   n=sc.nextInt();
	   int total=0;
	   int temp_n=n;
	   while(n!=0){
	       i=1;
	       fact_n=1;
	       lastdig=n%10;
	       while(i<=lastdig){
	           fact_n=fact_n*i;
	           i++;
	       }
	       total=total+fact_n;
	       n=n/10;
	   }
	   if(total==temp_n)
	    System.out.println(temp_n + " is a strong number\n");
	   else
	    System.out.println(temp_n + " is not a strong number\n");
	   
	   48. //
	   
	   System.out.println("Enter the starting range:");
	   int start=sc.nextInt();
	   System.out.println("Enter the ending range:");
	   int end=sc.nextInt();
	   for(int n=start;n<end;n++){
	    int i;
	   int fact_n,lastdig;
	   int total=0;
	   int temp_n=n;
	   while(n!=0){
	       i=1;
	       fact_n=1;
	       lastdig=n%10;
	       while(i<=lastdig){
	           fact_n=fact_n*i;
	           i++;
	       }
	       total=total+fact_n;
	       n=n/10;
	   }
	   if(total==temp_n)
	    System.out.println(temp_n + " is a strong number\n");
	   }
	   
	   49. //
	   
	   System.out.println("Enter the n value:");
	   int n=sc.nextInt();
	   System.out.println("Enter the first term:");
	   float a=sc.nextFloat();
	   System.out.println("Enter the difference:");
	   float d=sc.nextFloat();
	   float sum=0;
	   for(int i=0;i<n;i++){
	       sum=sum+a;
	       a=a+d;
	   }
	   System.out.println(sum);
	   
	   50. //
	   
	   System.out.print("Enter your number:");
	   int decimal = sc.nextInt();
	   int count=0,octal =0,rem,temp;
	   double res;
	   temp=decimal;
	   while(temp!=0){
	       rem=temp%8;
	       res=Math.pow(10,count);
	       octal=(int)(octal+rem*res);
	       temp/=8;
	       count++;
	   }
	   System.out.println(octal);
	   
	   
	   51. //
	   
	   System.out.print("Enter your number:");
	   int octal= sc.nextInt();
	   int decimal=0;
	   int n=0;
	   while(true){
	       if(octal==0){
	           break;
	       }
	       else{
	           int temp=octal%10;
	           decimal+=temp*Math.pow(8,n);
	           octal=octal/10;
	           n++;
	       }
	   }  
	   System.out.println(decimal);
	   
	   
	   52. //
	   
	   System.out.println("Enter the n value:");
	   int n=sc.nextInt();
	   System.out.println("Enter the first term:");
	   float a=sc.nextFloat();
	   System.out.println("Enter the difference:");
	   float r=sc.nextFloat();
	   float sum=0;
	   for(int i=0;i<n;i++){
	       sum=sum+a;
	       a=a*r;
	   }
	   System.out.println(sum);
	   
	   
	   53. //
	   
	   long binaryNumber=101001;
	   int octalNumber=0,decimalNumber=0,i=0;
	   while(binaryNumber!=0){
	       decimalNumber+=(binaryNumber%10)*Math.pow(2,i);
	       ++i;
	       binaryNumber/=10;
	   }
	   i=1;
	   while(decimalNumber!=0){
	       octalNumber+=(decimalNumber%8)*i;
	       decimalNumber/=8;
	       i*=10;
	   }
	   System.out.println(octalNumber);
	   
	   54. //
	   
	   int octalNumber=67;
	   int decimalNumber=0,i=0;
	   long binaryNumber=0;
	   while(octalNumber!=0){
	       decimalNumber+=(octalNumber%10)*Math.pow(8,i);
	       ++i;
	       octalNumber/=10;
	   }
	   i=1;
	   while(decimalNumber!=0){
	       binaryNumber+=(decimalNumber%2)*i;
	       decimalNumber/=2;
	       i*=10;
	   }
	   System.out.println(decimalNumber);
	   
	    55. //
        
        int n=s.nextInt();
        System.out.println(Integer.toHexString(n));
        
        
        56. //
        
        
        57. //
        
        String nstr="";
        char ch;
        String str=s.next();
        for (int i=0;i<str.length();i++)
        {
        ch= str.charAt(i); 
        nstr= ch+nstr;
        }
        System.out.println(nstr);
        
        58. // 
        
        String str=s.next();
        int i = 0;
        for(char c:str.toCharArray()) 
        i++;
        System.out.println(i);
        
        59. //
        
        int n=s.nextInt();
        int res=0,rem,count=0,temp;
        temp=n;
        while(n>0){
        rem=temp%10;
        n=n/10;
        count++;
        }
        int n1=temp;
        while(temp>0){
        rem=temp%10;
        res+=(Math.pow(rem,count));
        temp=temp/10;
        }
        if(res==n1)
            System.out.println("Armstrong");
        else
            System.out.println("not");
        
        61. //
        
        String str=s.next();
        int upper=0,lower=0,num=0,spl=0;
        for(int i=0;i<str.length();i++)
        {
            char ch=str.charAt(i);
            if(ch>='A'&&ch<='Z')
                upper++;
            else if(ch>='a'&&ch<='z')
                lower++;
            else if(ch>='0'&&ch<='9')
                num++;
            else
                spl++;
        }
        System.out.println("Lower:"+lower);
        System.out.println("Upper:"+upper);
        System.out.println("Number:"+num);
        System.out.println("Spl:"+spl);
*/

        
        
            
        //30. //Armstrong Number in given range
        
        Scanner sc=new Scanner(System.in);
        System.out.println("Input the starting range or number : ");
        int start=sc.nextInt();
        System.out.println("Input the ending range of number : ");
        int end=sc.nextInt();
        int rem, temp=num, sum=0;
        for(int i=0)
        }
        if(temp==sum)
            System.out.println(temp+" is an Armstrong number.");
        else
            System.out.println(temp+" is not an Armstrong number.");
        










	}
}
































































































































































































































































































































































































