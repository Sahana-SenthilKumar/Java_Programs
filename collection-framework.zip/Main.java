//                                         // COLLECTION FRAMEWORK
                                        
//                                         // COLLECTION INTERFACE
// import java.util.*;
// public class Main
// {
// 	public static void main(String[] args) {
// 		List l1=new ArrayList();
// 		List l2=new ArrayList();
// 		l1.add(10);
// 		l1.add(20);
// 		l1.add(30);
// 		l1.add(40);
// 		l2.addAll(l1);
// 		l1.add(50);
// 		l1.add(60);
// 		System.out.println(l1);
// 		System.out.println(l2);
// 		//l1.remove(4);
// // 		l1.remove(2);
// // 		System.out.println(l1);
// // 		l1.removeAll(l2);
// //      l1.retainAll(l2);
// // 		System.out.println(l1);;
// // 		System.out.println(l2.contains(60));
// // 		System.out.println(l1.contains(60));
// // 		System.out.println(l1.containsAll(l2));
// // 		System.out.println(l2.containsAll(l1));
// // 		List l3=new ArrayList();
// // 		System.out.println(l2.isEmpty());
// // 		System.out.println(l3.isEmpty());
// // 		l2.clear();
// // 		System.out.println(l2);
// //      System.out.println(l2.size());
// //      System.out.println(l1.size());
            
// 	}
// }





                                        // LIST INTERFACE
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		List l1=new ArrayList();
		List l2=new ArrayList();
		l1.add(0, 10);
		l1.add(2, 20);
		l1.add(1, 30);
		l1.add(4, 40);
		l2.addAll(5, l1);
		l1.add(5, 50);
		l1.add(6, 60);
		System.out.println(l1);
		System.out.println(l2);
            
	}
}
