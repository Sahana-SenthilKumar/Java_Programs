import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    int[] students = {1,1,1,0,0,1};
	    int[] sandwiches = {1,0,0,0,1,1};
	    int n=sandwiches.length;
	    Stack<Integer> s=new Stack<Integer>();
        Queue<Integer> q=new LinkedList<>();
        for(int i=n-1; i>=0; i--){
            s.push(sandwiches[i]);
        }
        //System.out.println(s.peek());
        for(int i=0; i<n; i++){
            q.add(students[i]);
        }
        //System.out.println(q);
        //System.out.println(s);
        int i=0;
        while(!s.empty() & i<n){
            if(s.peek()==q.peek()){
                s.pop();
                q.remove();
            }
            else {
                int w=q.remove();
                q.add(w);
                //System.out.println(q);
                i++;
            }
        }
        if(s.empty()){
            System.out.println("True");
        }
        
	}
}