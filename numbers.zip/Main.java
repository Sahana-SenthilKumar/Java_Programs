// import java.util.Scanner;
// import java.lang.Math;
// public class Main
// {
//     int fact(int a){
// 	    int fact=1;
// 	    for(int i=1;i<=a;i++){
// 	        fact=fact*i;
// 	    }
// 	    return fact;
// 	}
// 	public static void main(String[] args) {
		
/*

	1. //Reverse a Number
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number :");
		int num=sc.nextInt();
		int temp=num, rem, rev=0;
		while(num!=0){
		    rem=num%10;
		    rev=rev*10+rem;
		    num=num/10;
		}
		System.out.println("The reverse of "+temp+" is :"+rev);

		
	a. //Prime Number
 
        Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number :");
		int num=sc.nextInt();
		boolean prime=true;
		for(int i=2;i<=num/2;i++){
		    if(num%i==0){
		        prime=false;
		    }
		}
		if(prime)
		    System.out.println(num+" is prime.");
		else
		    System.out.println(num+" is not prime.");
		   
		  
	b. //Palindrome Numbers

        Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number :");
		int num=sc.nextInt();
		int temp=num, rem, rev=0;
		while(num!=0){
		    rem=num%10;
		    rev=rev*10+rem;
		    num=num/10;
		}
		if(temp==rev)
		    System.out.println("The number "+temp+" is a palindrome : "+rev);
		else
		    System.out.println("The number "+temp+" is not a palindrome : "+rev);
		    
    2. //Convert Number to Word
    
        Scanner sc=new Scanner(System.in);
	    System.out.println("Enter a number :");
		int num=sc.nextInt();
		String s=" ";
		int rem;
		for(int i=1;i<=num;num=num/10){
		    rem=num%10;
		    String string=s.append((char)rem);
		}
		char word=(char)num;
		System.out.println("The number "+num+" in words : "+word);
		
    
    3.//Peterson Number or Krishnamurthy number
  
        Scanner sc=new Scanner(System.in);
	    System.out.println("Enter a number :");
		int num=sc.nextInt();
		int rem, sum=0, temp=num;
		Main m=new Main();
		while(num>0){
		    rem=num%10;
		    sum=sum+m.fact(rem);
		    num=num/10;
		}
		if(temp==sum)
		    System.out.println(temp+" is a Peterson Number");
		else
		    System.out.println(temp+" is a not Peterson Number");
		    
    4. // Tech Number

import java.lang.Math;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter a number :");
		int num=sc.nextInt();
		int digit=0, result, temp=num, first=0, second=0, tech;
		Main m=new Main();
		while(num>0){
		    digit++;
		    num=num/10;
		}
		if(digit%2==0){
		    first=temp%((int)Math.pow(10,(digit/2)));
		    second=temp/((int)Math.pow(10,(digit/2)));
		    tech=(first+second)*(first+second);
		    if(tech==temp){
		        System.out.println(temp+" is a Tech Number");
		    }
		    else{
		        System.out.println(temp+" is a not Tech Number");
		    }
		}
		else{
		        System.out.println(temp+" is a not Tech Number");
		    }
	}
}



// 	}
    
    5. // Buzz Number
    
import java.lang.Math;
import java.util.Scanner;
public class Main
{
    public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter a number :");
		int num=sc.nextInt();
		int rem=num%10;
		
		if(num%7==0)    
		    System.out.println(num+" is a Buzz Number");
		else if(rem==7)
		    System.out.println(num+" is a Buzz Number");
		else    
		    System.out.println(num+" is a not Buzz Number");
    
    }
}

*/ 

    //6. // Fascinating Number
    
import java.lang.Math;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter a number :");
		int num=sc.nextInt();
		int n2=num*2, n3=num*3, count;
		String n=num+""+n2+""+n3;
		boolean found=true;
		for(char c='1';c<='9';c++){
		    count=0;
		    for(int i=0;i<n.length();i++){
		        int ch=n.charAt(i);
		        if(ch==c)
		            count++;
		}
		if(count>=1 || count==0){
		    found = false;
		    break;
		}
		
		}
		if(found)
		    System.out.println(num+" is a Fascinating Number");
		else
			System.out.println(num+" is not a Fascinating Number");

		
	}
}

    
    
	
// }
