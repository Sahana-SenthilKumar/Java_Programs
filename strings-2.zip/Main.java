import java.util.*;
import java.lang.*;
import java.math.*;
public class Main
{
    
 
    
                // Divisible by 7
    
    // static boolean divide(int num){
    //     while(!(num<=7)){
            
    //         int rem=num%10;
    //         int rev=0;
    //         rev=10*rev+rem;
    //         num=num/10;
    //         int res=num-(2*rev);
    //         //System.out.println(res);
    //         num=res;
            
            
    //     }
    //     System.out.println(num);
    //     if(Math.abs(num)==7){
    //         return true;
    //     }
    //     else
    //         return false;
    // }
    
    
    
	public static void main(String[] args) {
		
		
		
		            //  Reverse a String
		
// 		String s="i love programming very much";
//         String[] a = s.split("\\s");
//         for(int i=a.length-1; i>=0; i--){
//             System.out.print(a[i]+" ");
//         }
		    


                    //  Minimum deletion
                    
        // String s="aebcbda";
        // int i=0, j=s.length()-1;
        // int del=0;
        // while(i<j){
        //     if(s.charAt(i)==s.charAt(j)){
        //         i++;
        //         j--;
        //     } 
        //     else{
        //         del++;
        //         if(s.charAt(i+1)==s.charAt(j)){
        //             i++;
        //         } 
        //         else if(s.charAt(i)==s.charAt(j-1)){
        //             j--;
        //         } 
        //         else{
        //             i++;
        //             j--;
        //         }
        //     }
        // }
        // System.out.println(del);

        
        
                    
                    // Longest common prefix 
                    
        // //String[] a={"geeksforgeeks", "geeks", "geek", "geezer"};
        // String[] a={"apple", "ape", "april"};
        // Arrays.sort(a);
        // String s1=a[0], s2=a[a.length-1];
        // int index=0;
        // while(index<s1.length() && index<s2.length()){
        //     if(s1.charAt(index)==s2.charAt(index)){
        //         index++;
        //     }
        //     else
        //         break;
        // }
        // System.out.println(s1.substring(0,index));
        
        
        
                    //  Minimum distance
        
        // //String[] s = {"geeks", "for", "geeks", "contribute",  "practice"};
        // String[] s={"the", "quick", "brown", "fox", "quick"};
        // String w1 = "the", w2 = "fox";
        // int count = 0;
        // for (int i = 0; i < s.length; i++) {
        //     boolean find=false;
        //     if (s[i].equals(w1)) {
        //         //count++;
        //         for (int j = i + 1; j < s.length; j++) {
        //             //System.out.println(s[j]);
        //             count++;
        //             //System.out.println(count);
        //             if(s[j].equals(w1)){
        //                 count=0;
        //             }
        //             if (s[j].equals(w2)) {
        //                 find=true;
        //                 break;
        //             }
        //         }
        //         // if(find){
        //         //     break;
        //         // }
        //     }
        //     if(find)
        //         break;
        // }
        // System.out.println(count);
        
        
        
                    //  Divisible by 7
        
        // int num=371;
        // System.out.println(divide(num));
        
        
        
                    // Panagram
        
        // String s="The quick brown fox jumps over the lazy dog";
        // char[] a=s.toLowerCase().toCharArray();
        // Arrays.sort(a);
        // boolean pan=true;
        // for(char c='a';c<='z';c++){
        //     if(Arrays.binarySearch(a,c)<0){
        //         pan=false;
        //         break;
        //     }
        // }
        // if(pan)
        // System.out.println("Pangaram");
        // else    
        // System.out.println("Not Pangaram");
        
        
        
                    // Roman to Integer
                    
        // String s = "MCMIV";
        // int answer=0, number=0;
        // for (int i=s.length()-1; i>=0;i--)
        // {
        //   switch(s.charAt(i)){
        //       case 'I' : 
        //       number=1;
        //       break;
        //       case 'V' : 
        //       number=5;
        //       break;
        //       case 'X' : 
        //       number=10;
        //       break;
        //       case 'L' : 
        //       number=50;
        //       break;
        //       case 'C' : 
        //       number=100;
        //       break;
        //       case 'D' : 
        //       number=500;
        //       break;
        //       case 'M' : 
        //       number=1000;
        //       break;
        //     }
        //   if(4*number<answer)
        //       answer -= number;
        //   else
        //       answer += number;
        // }
        // System.out.println(answer);
        
        
        
                    // Integer to roman
                    
        // int num = 45;
        // StringBuilder s = new StringBuilder();
        // while (num >= 1000) {
        //     s.append('M');
        //     num -= 1000;
        // }
        // while (num >= 900) {
        //     s.append("CM");
        //     num -= 900;
        // }
        // while (num >= 500) {
        //     s.append('D');
        //     num -= 500;
        // }
        // while (num >= 400) {
        //     s.append("CD");
        //     num -= 400;
        // }
        // while (num >= 100) {
        //     s.append('C');
        //     num -= 100;
        // }
        // while (num >= 90) {
        //     s.append("XC");
        //     num -= 90;
        // }
        // while (num >= 50) {
        //     s.append('L');
        //     num -= 50;
        // }
        // while (num >= 40) {
        //     s.append("XL");
        //     num -= 40;
        // }
        // while (num >= 10) {
        //     s.append('X');
        //     num -= 10;
        // }
        // while (num >= 9) {
        //     s.append("IX");
        //     num -= 9;
        // }
        // while (num >= 5) {
        //     s.append('V');
        //     num -= 5;
        // }
        // while (num >= 4) {
        //     s.append("IV");
        //     num -= 4;
        // }
        // while (num >= 1) {
        //     s.append('I');
        //     num -= 1;
        // }

        // System.out.println(s.toString());
        
        
        
                    //  Isomorphic
                    
        // String s1= "abc", s2="xxy";
        // HashMap<Character, Character> count=new HashMap();
        // char c='a';
        // for(int i=0; i<s1.length(); i++){
        //     if(count.containsKey(s1.charAt(i))){
        //         c=count.get(s1.charAt(i));
        //         if(c!=s2.charAt(i)){
        //             System.out.println("False");
        //             return;
        //         }
        //     } 
        //     else if(!count.containsValue(s2.charAt(i))){
        //         count.put(s1.charAt(i), s2.charAt(i));
        //     } 
        //     else{
        //         System.out.println("False");
        //         return;
        //     }
        // }
        // System.out.println("True");
                    
                    
                    
                    // K-Anagram 
        
        // String s1 ="anagram", s2="grammar";
        // int k=3;
        // if(s1.length()!=s2.length()){
        //     System.out.println("Not anagram");
        //     return;
        // }
        // int[] count=new int[26];
        // for(char c : s1.toCharArray()){
        //     count[c-'a']++;
        // }
        // int dif=0;
        // for(char c : s2.toCharArray()){
        //     if(count[c-'a']>0) {
        //         count[c-'a']--;
        //     } 
        //     else{
        //         dif++;
        //     }
        // }
        // if(dif<=k&&(k-dif)>=0){
        //     System.out.println("Yes");
        // }
        // else
        //     System.out.println("No");
        
        
                    
                    
                    
                    //  Rotate string
                    
        // String s1 = "amazon", s2 = "azonam";
        // boolean ana=true;
        // char[] a=s1.toCharArray();
        // int cr=2, acr=2, i=0;
        // while(i<cr){
        //     char temp=a[a.length-1];
        //     for(int j=a.length-2; j>=0; j--){
        //         a[j+1]=a[j];
        //     }
        //     a[0]=temp;
        //     i++;
            
            
        // }
        // // for(char k : a)
        // //         System.out.print(k+" ");
        
        // i=0;
        // StringBuilder sb=new StringBuilder();
        // while(i<acr){
        //     char tem=a[a.length-1];
        //     for(int j=a.length-2; j>=0; j--){
        //         a[j+1]=a[j];
        //     }
        //     a[0]=tem;
        //     i++;
        // }
        // for(char k : a){
        //     sb.append(k);
        //     //System.out.print(k);
        // }
        // String s=sb.toString();
        // for(int r=0; r<s.length(); r++){
        //     if(!(s.charAt(r)==(s2.charAt(r)))){
        //         ana=false;
        //         break;
        //     }
        // }
        // System.out.println(ana);
        
        
        
                    // Subsequence
                    
        // String str="ggg";           
        // char[] s=str.toCharArray();
        // Set<String> sub=new HashSet<>();

        // int totsq=(int)Math.pow(2, s.length);

        // for (int i=0; i<totsq; i++) {
        //     StringBuilder sb=new StringBuilder();
        //     for (int j=0; j<s.length; j++) {
        //         if ((i & (1 << j)) > 0) {
        //             sb.append(s[j]);
        //         }
        //     }
        //     sub.add(sb.toString());
        // }

        // System.out.println(sub.size());
        
        
                    //  Equal point in a bracket
    
        // String s = "))";
        // int openCount = 0;
        // int closeCount = 0;
        // int index = -1;
        // boolean found=false;

        // for (int i = 0; i < s.length(); i++) {
        //     if (s.charAt(i) == '(') {
        //         openCount++;
        //     } 
        //     else if (s.charAt(i) == ')') {
        //         closeCount++;
        //     }

        //     if (openCount == closeCount) {
        //         found =true;
        //         index = i+1;
        //         break;
        //     }
        // }
        // if(!found){
        //     System.out.println(s.length());
        //     return;
        // }
        // if(index>-1)
        //     System.out.println(index);
        // else
        //     System.out.println("No pair");
        
        
        
                    //  Sum of two large numbers
                    
        // String s1= "7777555511111111", s2= "3332222221111";
        // BigInteger a=new BigInteger(s1);
        // BigInteger b=new BigInteger(s2);
        // BigInteger sum = a.add(b);
        // System.out.println(sum);
        
        
        
                    //  Multiply two large numbers
        
        // String n1="654154154151454545415415454", n2="63516561563156316545145146514654";            
        // BigInteger a=new BigInteger(n1);
        // BigInteger b=new BigInteger(n2);
        // BigInteger prod=a.multiply(b);
        // System.out.println(prod);
        
        
        
                    //  Replace String
                    
    //     String s="abababa", s1="aba", s2="a";
    //     String ans="";
    //     for(int i=0; i<s.length(); i++){
    //     int k=0;
    //     if(s.charAt(i)==s1.charAt(k) && i+s1.length()<=s.length()){
    //         int j;
    //         for(j=i; j<i+s1.length(); j++){
    //             if(s.charAt(j)!=s1.charAt(k)){
    //                 break;
    //             } 
    //             else{
    //                 k+=1;
    //             }
    //         }
    //         if(j==i+s1.length()){
    //             ans+=s2;
    //             i=j-1;
    //         } 
    //         else{
    //             ans+=s.charAt(i);
    //         }
    //     } 
    //     else{
    //         ans+=s.charAt(i);
    //     }
    // }
    // System.out.print(ans);
        
        
        
                    //  Longest prefix and suffix;
            
        // String s="abcab";
        // int len=0;
        // for (int i=0; i<s.length()/2;i++){
        //     if(s.substring(0,i+1).equals(s.substring(s.length()-i-1))){
        //         len=i+1;
        //     }
        // }
        // System.out.println(len);
        
        
        
                    //  Add binary string
                
        String a="1101", b="100";
        int i=a.length()-1, j=b.length()-1;
        int carry=0, sum=0;
        StringBuilder res=new StringBuilder();

        while(i>=0 || j>=0 || carry==1) {
            sum=carry;
            if(i>=0){
                sum=sum+a.charAt(i)-'0';
            } 
            if(j>=0){
               sum=sum+b.charAt(j)-'0'; 
            } 
            res.append((char)(sum%2+'0'));
            carry=sum/2;
            i--;
            j--;
        }
        System.out.print(res.reverse().toString());
        
        
    }
}
