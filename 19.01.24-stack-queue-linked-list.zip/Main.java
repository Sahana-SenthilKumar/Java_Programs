                                            // Stack in Queue


// import java.util.*;
// public class Main {
//     Queue<Integer> q1 = new LinkedList<>();
//     Queue<Integer> q2 = new LinkedList<>();
//     public static void main(String[] args) {
//         Main m = new Main();
//         m.push(1);
//         m.push(2);
//         m.push(3);
//         m.push(4);
//         m.push(5);
//         System.out.println("Popping elements:");
//         System.out.println(m.pop());
//         System.out.println(m.pop());
//         System.out.println(m.pop());
//         System.out.println(m.pop());
//         System.out.println(m.pop());
        
//     }
//     void push(int data) {
//         q1.add(data);
//     }
//     int pop() {
//         if (q1.isEmpty() && q2.isEmpty()) {
//             System.out.println("Stack is empty");
//             return -1; 
//         }
//         while (q1.size() > 1) {
//             q2.add(q1.poll());
//         }
//         int removedElement = q1.poll();
//         Queue<Integer> temp = q1;
//         q1 = q2;
//         q2 = temp;
//         return removedElement;
//     }
// }


                                    // Queue in Stack
                                    
// import java.util.Stack;
// public class Main {
//     Stack<Integer> stack1 = new Stack<>();
//     Stack<Integer> stack2 = new Stack<>();
//     public static void main(String[] args) {
//         Main queue = new Main();
//         queue.enqueue(1);
//         queue.enqueue(2);
//         queue.enqueue(3);
//         queue.enqueue(4);
//         queue.enqueue(5);
//         System.out.println(queue.dequeue());
//         System.out.println(queue.dequeue());
//         System.out.println(queue.dequeue());
//         System.out.println(queue.dequeue());
//         System.out.println(queue.dequeue());
//     }
//     void enqueue(int data) {
//         stack1.push(data);
//     }

//     int dequeue() {
//         if (stack1.isEmpty() && stack2.isEmpty()) {
//             System.out.println("Queue is empty");
//             return -1; 
//         }
//         if (stack2.isEmpty()) {
//             while (!stack1.isEmpty()) {
//                 stack2.push(stack1.pop());
//             }
//         }
//         return stack2.pop();
//     }
// }



        // Method 2
        
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
public class Main {
    Stack<Integer> stack1 = new Stack<>();
    Stack<Integer> stack2 = new Stack<>();
    public static void main(String[] args) {
        Main queue = new Main();
        queue.enqueue(1);
        queue.enqueue(2);
        queue.enqueue(3);
        List<Integer> dequeuedElements = queue.dequeueAll();
        System.out.println(dequeuedElements);
    }
    void enqueue(int data) {
        stack1.push(data);
    }
    List<Integer> dequeueAll() {
        List<Integer> dequeuedElements = new ArrayList<>();

        while (!stack1.isEmpty()) {
            stack2.push(stack1.pop());
        }
        while (!stack2.isEmpty()) {
            int element = stack2.pop();
            dequeuedElements.add(element);
        }
        return dequeuedElements;
    }
}