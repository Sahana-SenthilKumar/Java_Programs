//Longest subsequence of given sum

// import java.util.HashMap;
// public class Main {
//     public static void printLongestSubsequence(int[] arr, int k) {
//         int maxLength = 0;
//         int start = -1, end = -1;
//         HashMap<Integer, Integer> map = new HashMap<>();
//         int sum = 0;
//         for (int i = 0; i < arr.length; i++) {
//             sum += arr[i];
//             if (sum == k) {
//                 maxLength = i + 1;
//                 start = 0;
//                 end = i;
//             } else if (map.containsKey(sum - k)) {
//                 int len = i - map.get(sum - k);
//                 if (len > maxLength) {
//                     maxLength = len;
//                     start = map.get(sum - k) + 1;
//                     end = i;
//                 }
//             }
//             if (!map.containsKey(sum)) {
//                 map.put(sum, i);
//             }
//         }
//         for (int i = start; i <= end; i++) {
//             System.out.print(arr[i] + " ");
//         }
//         System.out.println();
//     }
//     public static void main(String[] args) {
//         int[] arr = {1,2,3,4};
//         int k = 6;
//         printLongestSubsequence(arr, k);
//     }
// }

        //Subsequence of max sum

// import java.io.*;
// import java.util.*;
// class Main{
//     static int maxi(int a[],int n){
//         int sum = 0;
//         int max = a[0];
//         for(int i = 1; i < n; i++){
//           if(max < a[i]){
//             max = a[i];
//           }
//         }
//         if (max <= 0) {     
//           return max;
//         }
//         for (int i = 0; i < n; i++){
//           if (a[i] > 0) {
//             sum += a[i];
//           }
//         }
//         return sum;
//     }
//     public static void main(String[] args)
//     {
//     	int[] a={1,2,3,4,5};
//     	int n=a.length;
//         System.out.println(maxi(a,n));
//     }
// }

import java.io.*;
import java.util.*;
class Main{
public static void Sub(int[] arr,int i,ArrayList<Integer> path)
{
    int sum=0;
    int max=0;
	if(i==arr.length)
	{
		if(max<sum){
		    max=sum;
		}
		    
	}
	else
	{
		
		path.add(arr[i]);
		sum+=arr[i];
		Sub(arr, i+1, path, ele);
		path.remove(path.size() - 1);
		sum-=arr[i];
		Sub(arr, i+1, path, ele);
	}
	return;
	
}
public static void main(String[] args)
{
	int[] arr={1, 2, 3, 4};
	ArrayList<Integer> path=new ArrayList<>();
    Sub(arr, 0, path);
    
}
}

//any one subsequence of sum

// import java.io.*;
// import java.util.*;
// class Main{
//     static ArrayList<Integer> sub(int[] arr, int targetSum){
//          int n = arr.length;
//         ArrayList<Integer>[] dp = new ArrayList[n];
//         for (int i = 0; i < n; i++) {
//             dp[i] = new ArrayList<>();
//             dp[i].add(arr[i]); 
//             for (int j = 0; j < i; j++) {
//                 if (arr[i] + arr[j] == targetSum && dp[i].size() < dp[j].size() + 1) {
//                     dp[i] = new ArrayList<>(dp[j]);
//                     dp[i].add(arr[i]);
//                 }
//             }
//         }
//         ArrayList<Integer> result = new ArrayList<>();
//         for (ArrayList<Integer> subsequence : dp) {
//             if (subsequence.size() > result.size()) {
//                 result = subsequence;
//             }
//         }
//         return result;
//     }
//     public static void main(String[] args)
//     {
//     	 int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
//         int sum = 17;
//         ArrayList<Integer> result = sub(arr,sum);
//         System.out.println(result);
//     }
// }

        //Subsequence with given element
        
import java.io.*;
import java.util.*;
class Main{
public static void Sub(int[] arr,int i,ArrayList<Integer> path, int ele)
{
	if(i==arr.length)
	{
		if(path.contains(ele))
		    System.out.println(path);
	}
	else
	{
		
		path.add(arr[i]);
		Sub(arr, i+1, path, ele);
		path.remove(path.size() - 1);
		Sub(arr, i+1, path, ele);
	}
	return;
	
}
public static void main(String[] args)
{
	int[] arr={1, 2, 3, 4};
	int ele=2;
	ArrayList<Integer> path=new ArrayList<>();
    Sub(arr, 0, path, ele);
    
}
}